package Plugins::DarcPrePlayer::Plugin;
use strict;
use warnings;
use base qw(Slim::Plugin::Base);
use Slim::Control::Request;
use Slim::Player::Client;
use Slim::Player::Song;
use Slim::Player::CapabilitiesHelper;
use Slim::Player::TranscodingHelper;
use Slim::Music::Info;
use Slim::Utils::Misc;
use File::Temp qw(tempdir);
use File::Basename qw(dirname);
use File::Spec;
use Cwd qw(abs_path);
use Digest::SHA qw(sha256_hex);
use MIME::Base64 qw(decode_base64 encode_base64);
use JSON::XS qw(decode_json encode_json);
use Fcntl qw(:DEFAULT :flock :mode);
use POSIX qw(_exit WNOHANG);
use Scalar::Util qw(refaddr);

my ($root,$dir,$cfg,$armed,$command,$rule,$preflight_pid,$selector_original,$selector_hook);
sub getDisplayName { 'DARC_PREPLAYER_DIAGNOSTIC' }

sub read_json {
    my ($path,$limit)=@_;
    return unless -f $path && -s $path <= $limit;
    open my $f,'<',$path or return;binmode $f;local $/;
    my $bytes=<$f>;close $f;
    my $v=eval {decode_json($bytes)};return $@ ? undef : $v;
}

sub write_new {
    my ($path,$bytes)=@_;
    sysopen my $f,$path,O_WRONLY|O_CREAT|O_EXCL,0600 or return;
    binmode $f;my $ok=print {$f} $bytes;$ok &&= close $f;
    return $ok;
}

sub initPlugin {
    my ($class)=@_;
    $class->SUPER::initPlugin();
    $root=dirname(abs_path(__FILE__));
    return unless $root =~ m{\A/[A-Za-z0-9_./-]+\z};
    $cfg=read_json(File::Spec->catfile($root,'config.json'),65536);
    return unless ref($cfg) eq 'HASH' && ($cfg->{mac} || '') =~ /\A(?:[0-9a-f]{2}:){5}[0-9a-f]{2}\z/
        && ($cfg->{api_key} || '') =~ /\A[0-9a-f]{48}\z/
        && ref($cfg->{sources}) eq 'ARRAY' && @{$cfg->{sources}}>=1 && @{$cfg->{sources}}<=10;
    $dir=tempdir('darc-preplayer-XXXXXXXX',TMPDIR=>1,CLEANUP=>1);
    return unless $dir =~ m{\A/[A-Za-z0-9_./-]+\z};
    $rule='flc-wav-daphile-'.$cfg->{mac};
    $command='/usr/bin/python3 -I -B '.$root.'/entry.py '.$dir.' $URL$';
    Slim::Control::Request::addDispatch(['darcbench','_action','_key','_arg'],[0,0,0,\&handle]);
}

sub url_for {
    my ($role)=@_;
    my ($source)=grep { $_->{role} eq $role } @{$cfg->{sources}};
    return $source ? Slim::Utils::Misc::fileURLFromPath($source->{path}) : undef;
}

sub engine_bin_registered {
    my $registered=Slim::Utils::Misc::findbin('darc-camilladsp');
    my $own=abs_path(File::Spec->catfile($root,'Bin','x86_64-linux','darc-camilladsp'));
    return ($registered && $own && abs_path($registered) eq $own) ? 1 : 0;
}

sub permitted {
    my ($song)=@_;
    return 0 unless $cfg && $armed && $song;
    my $client=eval {$song->master()};
    my $url=eval {$song->currentTrack()->url()};
    return 0 unless $client && lc($client->id()) eq $cfg->{mac} && defined $url;
    return scalar grep { $url eq Slim::Utils::Misc::fileURLFromPath($_->{path}) } @{$cfg->{sources}};
}

# Delegate every unrelated invocation verbatim; the stock selector receives
# its per-call output-format override only for an opted-in file and player.
sub install_selector {
    return 0 if $selector_hook;
    $selector_original=\&Slim::Player::TranscodingHelper::getConvertCommand2;
    $selector_hook=sub {
        my @args=@_;
        if (ref($args[0]) eq 'Slim::Player::Song' && ($args[1] || '') eq 'flc'
            && !$args[5] && permitted($args[0])) {
            my $seek=eval {$args[0]->seekdata()};
            if ($seek && ($seek->{timeOffset} || $seek->{sourceStreamOffset} || $seek->{restartOffset})) {
                return wantarray ? (undef,'PROBLEM_CONVERT_FILE') : undef;
            }
            $args[5]='wav';
        }
        return $selector_original->(@args);
    };
    { no warnings 'redefine'; *Slim::Player::TranscodingHelper::getConvertCommand2=$selector_hook; }
    return 1;
}

sub refused {
    my ($request,$reason)=@_;
    $request->addResult('state','refused');
    $request->addResult('reason',$reason) if defined $reason;
    $request->setStatusDone();
}

sub disarm_internal {
    unless ($armed) {
        return (1,'idle') unless $dir;
        if ($preflight_pid && waitpid($preflight_pid,WNOHANG)==0) {return (0,'preflight-active');}
        my $pre=File::Spec->catfile($dir,'preflight.json');
        return (0,'cleanup-incomplete') if -e $pre && !unlink($pre);
        undef $preflight_pid;
        return (1,'idle');
    }
    my $lock=File::Spec->catfile($dir,'pipeline.lock');
    sysopen my $lf,$lock,O_RDWR|O_CREAT,0600 or return (0,'lock-unavailable');
    return (0,'pipeline-active') unless flock($lf,LOCK_EX|LOCK_NB);
    my $current=$Slim::Player::TranscodingHelper::commandTable{$rule};
    if (!defined($current) || $current ne $command) {close $lf;return (0,'rule-drift');}
    my $caps=$Slim::Player::TranscodingHelper::capabilities{$rule};
    if (ref($caps) ne 'HASH' || keys(%$caps)!=2 || ($caps->{F} || '') ne 'noArgs' || ($caps->{I} || '') ne 'noArgs') {
        close $lf;return (0,'capability-drift');
    }
    if (!$selector_hook || refaddr(\&Slim::Player::TranscodingHelper::getConvertCommand2)!=refaddr($selector_hook)) {
        close $lf;return (0,'selector-drift');
    }
    if ($preflight_pid && waitpid($preflight_pid,WNOHANG)==0) {close $lf;return (0,'preflight-active');}
    # A SIGKILL can prevent Python's NamedTemporaryFile cleanup.  Only remove
    # owned, private, regular files matching our exact engine-config pattern.
    opendir my $dh,$dir or do {close $lf;return (0,'cleanup-incomplete');};
    my @configs=grep { /\Adarc-preplayer-[A-Za-z0-9_-]{8,}\.json\z/ } readdir $dh;
    closedir $dh;
    for my $name (@configs) {
        my $path=File::Spec->catfile($dir,$name);
        my @st=lstat($path);
        if (!@st || !S_ISREG($st[2]) || $st[3]!=1 || $st[4]!=$> || ($st[2]&0077)) {
            close $lf;return (0,'cleanup-invalid-config');
        }
        if (!unlink($path)) {close $lf;return (0,'cleanup-incomplete');}
    }
    for my $name ('manifest.json','profile.json','preflight.json') {
        my $path=File::Spec->catfile($dir,$name);
        if (-e $path && !unlink($path)) {close $lf;return (0,'cleanup-incomplete');}
    }
    { no warnings 'redefine'; *Slim::Player::TranscodingHelper::getConvertCommand2=$selector_original; }
    undef $selector_hook;undef $selector_original;
    undef $preflight_pid;
    delete $Slim::Player::TranscodingHelper::commandTable{$rule};
    delete $Slim::Player::TranscodingHelper::capabilities{$rule};
    $armed=0;close $lf;
    return (1,'disarmed');
}

sub handle {
    my ($request)=@_;
    return refused($request,'disabled') unless $cfg && $dir;
    return refused($request,'key') unless ($request->getParam('_key') || '') eq $cfg->{api_key};
    my $action=$request->getParam('_action') || '';
    my $arg=$request->getParam('_arg') || '';
    my $pre=File::Spec->catfile($dir,'preflight.json');
    if ($action eq 'preflight') {
        return refused($request,'non-root-required') if $>==0;
        return refused($request,'preflight-already-started') if $preflight_pid || -e $pre;
        my $pid=fork();return refused($request,'fork') unless defined $pid;
        if (!$pid) {
            exec {'/usr/bin/python3'} '/usr/bin/python3','-I','-B',File::Spec->catfile($root,'preflight.py'),$root,$dir;
            _exit(1);
        }
        $preflight_pid=$pid;$request->addResult('state','preflight-started');
    } elsif ($action eq 'status') {
        my $result=read_json($pre,65536);
        if (!$result && $preflight_pid && waitpid($preflight_pid,WNOHANG)==$preflight_pid) {
            $request->addResult('preflight_error','worker-exited-without-result');
        }
        if ($result) {
            delete $result->{engine_path};
            $request->addResult('preflight',$result);
        }
        my $client=Slim::Player::Client::getClient($cfg->{mac});
        $request->addResult('engine_bin_registered',engine_bin_registered());
        $request->addResult('player_connected',$client ? 1 : 0);
        $request->addResult('formats',[Slim::Player::CapabilitiesHelper::supportedFormats($client)]) if $client;
        $request->addResult('state',$armed ? 'armed' : ($result ? 'preflight-complete' : 'idle'));
    } elsif ($action eq 'arm') {
        return refused($request,'already-armed') if $armed;
        my $ready=read_json($pre,65536);
        return refused($request,'preflight') unless $ready && $ready->{state} eq 'ready' && $ready->{engine_path};
        return refused($request,'engine-bin-unregistered') unless engine_bin_registered();
        return refused($request,'rule-exists') if exists $Slim::Player::TranscodingHelper::commandTable{$rule}
            || exists $Slim::Player::TranscodingHelper::capabilities{$rule};
        return refused($request,'profile-size') if length($arg)>90000;
        my $raw=decode_base64($arg);
        return refused($request,'profile-encoding') unless encode_base64($raw,'') eq $arg;
        return refused($request,'profile-sha') unless sha256_hex($raw) eq $cfg->{profile_sha256};
        my $profile=eval {decode_json($raw)};
        return refused($request,'profile-json') if $@ || ref($profile) ne 'HASH';
        my @sources=map { +{path=>$_->{path},sha256=>$_->{sha256},rate=>$_->{rate},bits=>$_->{bits}} } @{$cfg->{sources}};
        my $manifest=encode_json({version=>1,sources=>\@sources,profile_sha256=>$cfg->{profile_sha256},
                                  engine_sha256=>$cfg->{engine_sha256}});
        my $profile_path=File::Spec->catfile($dir,'profile.json');
        my $manifest_path=File::Spec->catfile($dir,'manifest.json');
        return refused($request,'profile-create') unless write_new($profile_path,$raw);
        if (!write_new($manifest_path,$manifest)) {unlink $profile_path;return refused($request,'manifest-create');}
        $Slim::Player::TranscodingHelper::capabilities{$rule}={F=>'noArgs',I=>'noArgs'};
        $Slim::Player::TranscodingHelper::commandTable{$rule}=$command;
        $armed=1;
        if (!install_selector()) { $armed=0;return refused($request,'selector-install'); }
        $request->addResult('state','armed');
    } elsif ($action eq 'urls') {
        return refused($request,'not-armed') unless $armed;
        $request->addResult('urls',{map {$_->{role}=>url_for($_->{role})} @{$cfg->{sources}}});
        $request->addResult('state','ready');
    } elsif ($action eq 'inspect') {
        return refused($request,'not-armed') unless $armed;
        my $client=Slim::Player::Client::getClient($cfg->{mac});
        return refused($request,'player') unless $client;
        my $song=Slim::Player::Song->new($client,0);
        return refused($request,'queue') unless $song && permitted($song);
        my $type=Slim::Music::Info::contentType($song->currentTrack());
        my ($selected,$error)=Slim::Player::TranscodingHelper::getConvertCommand2($song,$type,['F','I'],[],[]);
        return refused($request,'selector') unless $selected;
        $request->addResult('state','inspected');
        $request->addResult('source',$type);
        $request->addResult('profile',$selected->{profile});
        $request->addResult('format',$selected->{streamformat});
        $request->addResult('expected',($selected->{profile} eq $rule && $selected->{command} eq $command) ? 1 : 0);
    } elsif ($action eq 'disarm') {
        my ($ok,$state)=disarm_internal();return refused($request,$state) unless $ok;
        $request->addResult('state',$state);
    } else {return refused($request,'action');}
    $request->setStatusDone();
}

sub shutdownPlugin {
    my ($class)=@_;
    disarm_internal();
    $class->SUPER::shutdownPlugin();
}
1;
