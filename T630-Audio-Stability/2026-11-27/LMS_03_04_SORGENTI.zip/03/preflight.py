#!/usr/bin/env python3
"""Read-only validation of fixed local inputs and executable identities."""
import errno,fcntl,hashlib,json,os,signal,stat,subprocess,sys
from pathlib import Path

def sha_fd(fd):
    h=hashlib.sha256()
    while True:
        b=os.read(fd,65536)
        if not b:break
        h.update(b)
    return h.hexdigest()

def check_file(path,expected,executable=False,max_size=60*1024*1024,probe_lease=False):
    result={'readable':False,'sha_match':False,'executable':False}
    try:
        fd=os.open(path,os.O_RDONLY|os.O_CLOEXEC|getattr(os,'O_NOFOLLOW',0))
        try:
            before=os.fstat(fd)
            if not stat.S_ISREG(before.st_mode) or before.st_size>max_size:raise ValueError('file-size-or-type')
            result['readable']=True
            result['st_uid']=before.st_uid
            result['bytes']=before.st_size
            result['executable']=bool(os.access(path,os.X_OK)) if executable else None
            result['sha_match']=(sha_fd(fd)==expected)
            after=os.fstat(fd)
            result['stable']=(before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns,before.st_ctime_ns)==(
                after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns)
            if probe_lease:
                result['read_lease_acquired']=False;result['read_lease_released']=False
                previous=signal.signal(signal.SIGIO,lambda _n,_frame:None)
                try:
                    fcntl.fcntl(fd,fcntl.F_SETOWN,os.getpid())
                    fcntl.fcntl(fd,fcntl.F_SETLEASE,fcntl.F_RDLCK)
                    result['read_lease_acquired']=True
                    fcntl.fcntl(fd,fcntl.F_SETLEASE,fcntl.F_UNLCK)
                    result['read_lease_released']=True
                except OSError as exc:
                    result['read_lease_errno']=exc.errno
                    result['read_lease_error']=errno.errorcode.get(exc.errno,'UNKNOWN')
                finally:signal.signal(signal.SIGIO,previous)
        finally:os.close(fd)
    except (OSError,ValueError) as exc:result['error']=type(exc).__name__
    return result

def main():
    if len(sys.argv)!=3 or os.geteuid()==0:raise RuntimeError('non-root fixed preflight required')
    package=Path(sys.argv[1]);session=Path(sys.argv[2])
    if session.stat().st_uid!=os.geteuid() or session.stat().st_mode&0o077:raise RuntimeError('invalid private session')
    cfg=json.loads((package/'config.json').read_bytes())
    sources=[check_file(row['path'],row['sha256'],max_size=256*1024*1024,probe_lease=True) for row in cfg['sources']]
    ffmpeg=check_file(cfg['ffmpeg'],cfg['ffmpeg_sha256'],True)
    engine=None;engine_checks=[]
    for row in cfg['engines']:
        if row.get('package_relative')!='Bin/x86_64-linux/darc-camilladsp':
            engine_checks.append({'error':'invalid-package-engine'});continue
        path=package/row['package_relative']
        check=check_file(path,cfg['engine_sha256'],True)
        check['execution_verified']=False
        if check.get('readable') and check.get('sha_match') and check.get('stable') and check.get('executable'):
            try:
                version=subprocess.run([str(path),'--version'],stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,timeout=5,check=False)
                check['execution_verified']=(version.returncode==0 and version.stdout.startswith(b'CamillaDSP 5.0.0-beta.2'))
            except (OSError,subprocess.SubprocessError) as exc:check['execution_error']=type(exc).__name__
        engine_checks.append(check)
        if engine is None and check.get('readable') and check.get('sha_match') and check.get('stable') and check.get('executable'):
            if check['execution_verified']:engine=str(path)
    ok=bool(engine and all(r.get('readable') and r.get('sha_match') and r.get('stable')
                           and r.get('read_lease_acquired') and r.get('read_lease_released') for r in sources)
            and ffmpeg.get('readable') and ffmpeg.get('sha_match') and ffmpeg.get('stable') and ffmpeg.get('executable'))
    result={'state':'ready' if ok else 'refused','sources':sources,'ffmpeg':ffmpeg,'fexecve_supported':os.execve in os.supports_fd,
            'engine_candidates':engine_checks,'engine_path':engine,'uid':os.geteuid()}
    if not result['fexecve_supported']:result['state']='refused'
    temp=session/'preflight.new';dest=session/'preflight.json'
    fd=os.open(temp,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    with os.fdopen(fd,'w') as f:json.dump(result,f,separators=(',',':'));f.flush();os.fsync(f.fileno())
    os.replace(temp,dest)

if __name__=='__main__':main()
