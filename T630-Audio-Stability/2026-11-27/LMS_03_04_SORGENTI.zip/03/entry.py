#!/usr/bin/env python3
"""Fixed allowlisted library URLs; no user-supplied command or path."""
import fcntl,json,os,sys
from pathlib import Path
from types import SimpleNamespace
from urllib.parse import urlsplit,unquote

def main():
    if len(sys.argv)!=3 or os.geteuid()==0:raise RuntimeError('non-root fixed session required')
    package=Path(__file__).resolve().parent
    session=Path(sys.argv[1])
    st=session.stat()
    if st.st_uid!=os.geteuid() or st.st_mode&0o077:raise RuntimeError('invalid private session')
    cfg=json.loads((package/'config.json').read_bytes())
    url=sys.argv[2]
    parsed=urlsplit(url)
    if parsed.scheme!='file' or parsed.netloc or parsed.query or parsed.fragment:
        raise RuntimeError('unrecognized diagnostic URL')
    path=unquote(parsed.path,errors='strict')
    roles={r['path']:r['path'] for r in cfg['sources']}
    if path not in roles:raise RuntimeError('unrecognized diagnostic URL')
    pre=json.loads((session/'preflight.json').read_bytes())
    if pre.get('state')!='ready':raise RuntimeError('preflight incomplete')
    lockfd=os.open(session/'pipeline.lock',os.O_RDWR|os.O_CREAT|os.O_CLOEXEC,0o600)
    try:
        fcntl.flock(lockfd,fcntl.LOCK_SH|fcntl.LOCK_NB)
        sys.path.insert(0,str(package))
        import stream_filter
        args=SimpleNamespace(input=roles[path],manifest=str(session/'manifest.json'),profile=str(session/'profile.json'),
            engine=pre['engine_path'],ffmpeg=cfg['ffmpeg'],tmpdir=str(session))
        return stream_filter.run(args)
    finally:os.close(lockfd)

if __name__=='__main__':
    try:sys.exit(main())
    except Exception as exc:
        print('DARC_PREPLAYER_REFUSED:'+type(exc).__name__,file=sys.stderr)
        sys.exit(2)
