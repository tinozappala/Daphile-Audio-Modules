#!/usr/bin/env python3
"""Allowlisted stereo FLACs -> gated Camilla -> streamed WAV."""
import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import signal
import stat
import subprocess
import sys
import tempfile
import types
import ctypes

SUPPORTED_RATES = (44100, 48000, 88200, 96000, 176400, 192000, 352800, 384000)
MAX_CONFIG = 65536
READ_CHUNK = 16384
EXPECTED_MODEL_SHA = 'eb6162816a40d47eca9011d65f86b3dc3f7d9ab6898b5bcd3633390a78a2ccb7'
EXPECTED_GATE_SHA = '5a7fe3ed2261d41d7f865f04b131b24e4df51557bc6afc360a67734bd205eb92'


class Refused(RuntimeError):
    pass


def child_parent_guard():
    # Linux PR_SET_PDEATHSIG: direct engine/ffmpeg children die if the LMS
    # pipeline entry dies before it can run its own cleanup. No privilege is
    # required; check the parent again to close the setup race.
    parent=os.getppid()
    libc=ctypes.CDLL(None,use_errno=True)
    if libc.prctl(1,signal.SIGKILL,0,0,0)!=0 or os.getppid()!=parent:
        os._exit(127)


def bounded_file(path, size):
    flags = os.O_RDONLY | os.O_CLOEXEC | getattr(os, 'O_NOFOLLOW', 0)
    fd = os.open(path, flags)
    try:
        st = os.fstat(fd)
        if not stat.S_ISREG(st.st_mode) or st.st_size > size:
            raise Refused('configuration-file-invalid')
        with os.fdopen(fd, 'rb', closefd=False) as f:
            data = f.read(size + 1)
        if len(data) > size:
            raise Refused('configuration-file-too-large')
        return data
    finally:
        os.close(fd)


def check_dependencies():
    here = Path(__file__).resolve().parent
    modules={}
    for name, expected in (('model.py', EXPECTED_MODEL_SHA), ('pcm_gate.py', EXPECTED_GATE_SHA)):
        data = bounded_file(here / 'peq' / name, MAX_CONFIG)
        if hashlib.sha256(data).hexdigest() != expected:
            raise Refused('dependency-identity')
        # Execute exactly the checked bytes, with no import/cache race.
        module=types.ModuleType('checked_'+name[:-3])
        module.__file__=str(here/'peq'/name)
        exec(compile(data,module.__file__,'exec'),module.__dict__)
        modules[name]=module
    return modules['model.py'],modules['pcm_gate.py']


def validate_manifest(data):
    try: m = json.loads(data)
    except (UnicodeDecodeError, ValueError) as exc: raise Refused('manifest-invalid') from exc
    if not isinstance(m, dict) or set(m) != {'version', 'sources', 'profile_sha256', 'engine_sha256'} or m['version'] != 1:
        raise Refused('manifest-shape')
    def digest(x):
        return isinstance(x, str) and len(x) == 64 and all(c in '0123456789abcdef' for c in x)
    if not digest(m['profile_sha256']) or not digest(m['engine_sha256']):
        raise Refused('manifest-digest')
    if not isinstance(m['sources'], list) or not 1 <= len(m['sources']) <= 10:
        raise Refused('manifest-source-count')
    seen = set()
    for source in m['sources']:
        if (not isinstance(source, dict) or set(source) != {'path', 'sha256', 'rate', 'bits'}
            or not isinstance(source['path'], str) or not source['path'].startswith('/')
            or not source['path'].lower().endswith('.flac') or not digest(source['sha256'])
            or type(source['rate']) is not int or source['rate'] not in SUPPORTED_RATES
            or type(source['bits']) is not int or source['bits'] not in (16, 24)):
            raise Refused('manifest-source-invalid')
        if source['path'] in seen: raise Refused('manifest-duplicate-source')
        seen.add(source['path'])
    return m


def flac_info(fd):
    os.lseek(fd, 0, os.SEEK_SET)
    header = os.read(fd, 42)
    if len(header) != 42 or header[:4] != b'fLaC' or header[4] & 0x7f != 0 or header[5:8] != b'\x00\x00\x22':
        raise Refused('flac-streaminfo-missing')
    packed = int.from_bytes(header[18:26], 'big')
    rate = packed >> 44
    channels = ((packed >> 41) & 7) + 1
    bits = ((packed >> 36) & 31) + 1
    total_samples = packed & ((1 << 36) - 1)
    if rate not in SUPPORTED_RATES or channels != 2 or bits not in (16, 24) or not total_samples:
        raise Refused('flac-geometry-unsupported')
    os.lseek(fd, 0, os.SEEK_SET)
    return {'rate':rate, 'channels':channels, 'bits':bits, 'total_samples':total_samples}


def source_identity(st):
    return (st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns,st.st_ctime_ns)


def open_verified_source(path, entry):
    flags = os.O_RDONLY | os.O_CLOEXEC | getattr(os,'O_NOFOLLOW',0)
    fd = os.open(path,flags)
    try:
        before = os.fstat(fd)
        if not stat.S_ISREG(before.st_mode): raise Refused('source-not-regular')
        # A supported read lease rejects an already-open local writer, and a
        # later local writer requests a break (SIGIO). Network FS semantics are
        # filesystem-specific and remain an explicit deployment prerequisite.
        fcntl.fcntl(fd,fcntl.F_SETOWN,os.getpid())
        try: fcntl.fcntl(fd,fcntl.F_SETLEASE,fcntl.F_RDLCK)
        except OSError as exc: raise Refused('source-read-lease-unavailable') from exc
        digest=hashlib.sha256()
        while True:
            data=os.read(fd,65536)
            if not data:break
            digest.update(data)
        if digest.hexdigest()!=entry['sha256'] or source_identity(before)!=source_identity(os.fstat(fd)):
            raise Refused('source-hash-or-identity')
        info=flac_info(fd)
        if (info['rate'],info['bits'])!=(entry['rate'],entry['bits']):
            raise Refused('source-metadata')
        return fd, info, source_identity(before)
    except BaseException:
        os.close(fd)
        raise


def stop_children(children):
    for p in reversed(children):
        if p.poll() is None:
            try:p.terminate()
            except ProcessLookupError:pass
    for p in reversed(children):
        try:p.wait(timeout=3)
        except subprocess.TimeoutExpired:
            try:p.kill()
            except ProcessLookupError:pass
            p.wait(timeout=3)


def run(args):
    model,gate_module=check_dependencies()
    manifest=validate_manifest(bounded_file(args.manifest, MAX_CONFIG))
    matching=[s for s in manifest['sources'] if s['path']==args.input]
    if len(matching)!=1:raise Refused('source-not-allowed')
    profile_raw=bounded_file(args.profile,MAX_CONFIG)
    if hashlib.sha256(profile_raw).hexdigest()!=manifest['profile_sha256']:
        raise Refused('profile-identity')
    try:profile=json.loads(profile_raw)
    except (UnicodeDecodeError,ValueError) as exc:raise Refused('profile-invalid') from exc
    # Signal is installed before the lease is acquired.  A lease break is a
    # failure, never a request to continue with a potentially changed file.
    def stop(_n,_frame):raise Refused('interrupted-or-source-lease-break')
    previous_io=signal.signal(signal.SIGIO,stop)
    previous_term=signal.signal(signal.SIGTERM,stop)
    fd=None;cfg=None;children=[]
    try:
        fd, info, identity=open_verified_source(args.input,matching[0])
        profile=model.validate(profile,info['rate'])
        if not profile['enabled'] or profile['bypass']:raise Refused('profile-not-active')
        config=model.compile_config(profile,info['rate'],2048,
             {'type':'Stdin','channels':2,'format':'S32_LE'},
             {'type':'Stdout','channels':2,'format':'S32_LE'})
        config['devices']['queuelimit']=4
        encoded=json.dumps(config,allow_nan=False,separators=(',',':')).encode()
        if len(encoded)>MAX_CONFIG:raise Refused('compiled-profile-too-large')
        engine_path=Path(args.engine)
        engine_raw_hash=hashlib.sha256()
        engine_fd=os.open(engine_path,os.O_RDONLY|os.O_CLOEXEC|getattr(os,'O_NOFOLLOW',0))
        try:
            engine_identity=source_identity(os.fstat(engine_fd))
            if not stat.S_ISREG(os.fstat(engine_fd).st_mode):raise Refused('engine-not-regular')
            while True:
                data=os.read(engine_fd,65536)
                if not data:break
                engine_raw_hash.update(data)
            if engine_raw_hash.hexdigest()!=manifest['engine_sha256'] or source_identity(os.fstat(engine_fd))!=engine_identity:
                raise Refused('engine-identity')
            cfg=tempfile.NamedTemporaryFile(prefix='darc-preplayer-',suffix='.json',dir=args.tmpdir,mode='wb')
            os.fchmod(cfg.fileno(),0o600);cfg.write(encoded);cfg.flush()
            if os.execve not in os.supports_fd:raise Refused('fexecve-unavailable')
            trampoline='import os,sys; os.execve(int(sys.argv[1]), [sys.argv[2],sys.argv[3]], os.environ)'
            engine=subprocess.Popen([sys.executable,'-I','-c',trampoline,str(engine_fd),str(engine_path),cfg.name],
                 stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,
                 pass_fds=(engine_fd,),preexec_fn=child_parent_guard)
            children.append(engine)
        finally:os.close(engine_fd)
        engine_input=engine.stdin
        engine_output=engine.stdout
        decoder=subprocess.Popen([args.ffmpeg,'-nostdin','-v','error','-i','pipe:0','-f','s32le',
              '-acodec','pcm_s32le','-ac','2','pipe:1'],stdin=fd,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,
              preexec_fn=child_parent_guard)
        children.append(decoder)
        encoder=subprocess.Popen([args.ffmpeg,'-nostdin','-v','error','-f','s32le','-ar',str(info['rate']),
              '-ac','2','-i','pipe:0','-c:a','pcm_s32le','-f','wav','pipe:1'],
              stdin=engine_output,stdout=sys.stdout.buffer,stderr=subprocess.DEVNULL,preexec_fn=child_parent_guard)
        children.append(encoder)
        engine.stdout.close()
        gate=gate_module.PCMGate('S32_LE')
        while True:
            block=decoder.stdout.read1(READ_CHUNK)
            if not block:break
            accepted=gate.feed(block)
            if accepted:
                engine_input.write(accepted);engine_input.flush()
        accepted=gate.finish()
        if accepted:
            engine_input.write(accepted);engine_input.flush()
        engine_input.close()
        if decoder.wait(timeout=10)!=0:raise Refused('decoder-failed')
        if engine.wait(timeout=10)!=0:raise Refused('engine-failed')
        if encoder.wait(timeout=10)!=0:raise Refused('encoder-failed')
        if source_identity(os.fstat(fd))!=identity:raise Refused('source-changed')
        return 0
    except gate_module.GateError as exc:
        raise Refused('pcm-gate-'+str(exc)) from exc
    finally:
        stop_children(children)
        if cfg is not None:cfg.close()
        if fd is not None:
            try:fcntl.fcntl(fd,fcntl.F_SETLEASE,fcntl.F_UNLCK)
            finally:os.close(fd)
        signal.signal(signal.SIGIO,previous_io)
        signal.signal(signal.SIGTERM,previous_term)


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--input',required=True)
    p.add_argument('--manifest',required=True)
    p.add_argument('--profile',required=True)
    p.add_argument('--engine',default='/usr/bin/camilladsp')
    p.add_argument('--ffmpeg',default='/usr/bin/ffmpeg')
    p.add_argument('--tmpdir',default='/tmp')
    args=p.parse_args()
    try:return run(args)
    except (Refused, OSError, ValueError, BrokenPipeError, subprocess.SubprocessError) as exc:
        # OSError may contain private filenames; do not emit its message.
        reason=str(exc) if isinstance(exc,Refused) else type(exc).__name__
        print('PREPLAYER_REFUSED:'+reason,file=sys.stderr)
        return 2


if __name__=='__main__':raise SystemExit(main())
