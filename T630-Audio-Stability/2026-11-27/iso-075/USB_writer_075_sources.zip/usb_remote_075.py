"""Target-side .72-to-.75 USB writer and same-boot restoration.

Never called on import. All potentially destructive operations require the
exact observed removable USB, an internal-disk boot, a verified staged image,
an exclusive descriptor and a single-use journal.
"""
import base64
try:import fcntl
except ImportError:fcntl=None  # Local static/unit fixtures may run on Windows.
import hashlib
import json
import mmap
import os
from pathlib import Path
import re
import stat
import subprocess
import sys
import time
import uuid

TARGET=None
INTERNAL=None
TARGET_NAME=None
INTERNAL_NAME=None
TARGET_SIZE=None
INTERNAL_SIZE=None
OLD_SIZE=808286208
OLD_SHA='d5e4c2d90b722a15be0de5814f5a6d71543d36a52dcc407316eb586126bc8c47'
IMAGE_SIZE=808290304
IMAGE_SHA='76081f0321226e3dac8a8d6fd7f821a340a640c7e35ff2a24497f12742c5abd8'
EXTRA_SIZE=IMAGE_SIZE-OLD_SIZE
USB_VENDOR=None
USB_PRODUCT=None
USB_SERIAL=None
PRODUCT_CONTAINS=None
IDENTITY=None
BACKUP_BYTES=4*1024*1024
BLKGETSIZE64=0x80081272
BLKSSZGET=0x1268
BLKGETDISKSEQ=0x80081280
BLKFLSBUF=0x1261
STATE=Path('/run/daphile-live-usb-write-075.json')


def require(value,message):
    if not value:raise RuntimeError(message)


def configure_identity(spec):
    """Validate the private, previously observed physical target identity."""
    global TARGET,INTERNAL,TARGET_NAME,INTERNAL_NAME,TARGET_SIZE,INTERNAL_SIZE
    global USB_VENDOR,USB_PRODUCT,USB_SERIAL,PRODUCT_CONTAINS,IDENTITY
    keys={'target_name','internal_name','target_size','internal_size','usb_vendor','usb_product','usb_serial','product_contains'}
    require(type(spec) is dict and set(spec)==keys,'invalid private identity fields')
    for name in ('target_name','internal_name'):
        require(type(spec[name]) is str and re.fullmatch(r'sd[a-z]+',spec[name]),'invalid disk name')
    require(spec['target_name']!=spec['internal_name'],'target and internal disk overlap')
    for name in ('target_size','internal_size'):
        require(type(spec[name]) is int and spec[name]>IMAGE_SIZE+BACKUP_BYTES and spec[name]%512==0,
                'invalid disk size')
    for name in ('usb_vendor','usb_product'):
        require(type(spec[name]) is str and re.fullmatch(r'[0-9a-f]{4}',spec[name]),'invalid USB identifier')
    require(type(spec['usb_serial']) is str and re.fullmatch(r'[A-Za-z0-9._:-]{1,128}',spec['usb_serial']),
            'invalid USB serial')
    require(type(spec['product_contains']) is str and re.fullmatch(r'[A-Za-z0-9 ._-]{1,80}',spec['product_contains']),
            'invalid product identity')
    IDENTITY=dict(spec);TARGET_NAME=spec['target_name'];INTERNAL_NAME=spec['internal_name']
    TARGET='/dev/'+TARGET_NAME;INTERNAL='/dev/'+INTERNAL_NAME
    TARGET_SIZE=spec['target_size'];INTERNAL_SIZE=spec['internal_size']
    USB_VENDOR=spec['usb_vendor'];USB_PRODUCT=spec['usb_product'];USB_SERIAL=spec['usb_serial']
    PRODUCT_CONTAINS=spec['product_contains']


def digest(data):return hashlib.sha256(data).hexdigest()


def ioctl_int(fd,op,size):
    raw=bytearray(size);fcntl.ioctl(fd,op,raw,True)
    return int.from_bytes(raw,sys.byteorder)


def field(path):return Path(path).read_text().strip()


def devpair(number):return str(os.major(number))+':'+str(os.minor(number))


def device(name):
    path=Path('/dev')/name;node=path.lstat()
    require(stat.S_ISBLK(node.st_mode) and not path.is_symlink(),'device path is not a direct block node')
    sysnode=Path('/sys/class/block')/name
    require(field(sysnode/'dev')==devpair(node.st_rdev),'device and sysfs rdev differ')
    parent=sysnode.resolve(strict=True)
    sectors=int(field(sysnode/'size'));size=sectors*512
    sequence=int(field(sysnode/'diskseq'))
    require(sequence>0,'diskseq unavailable')
    return {'path':str(path),'rdev':devpair(node.st_rdev),'size_bytes':size,'diskseq':sequence,
            'sysfs':str(parent),'removable':int(field(sysnode/'removable'))}


def usb_identity():
    node=(Path('/sys/class/block')/TARGET_NAME/'device').resolve(strict=True)
    for p in (node,*node.parents):
        if (p/'idVendor').is_file() and (p/'idProduct').is_file():
            def optional(n):
                q=p/n;return field(q) if q.is_file() else ''
            return {'path':str(p),'vendor_id':optional('idVendor'),'product_id':optional('idProduct'),
                    'serial':optional('serial'),'busnum':optional('busnum'),'devnum':optional('devnum'),
                    'manufacturer':optional('manufacturer'),'product':optional('product')}
    raise RuntimeError('target is not descended from a USB device')


def partitions(disk=None):
    if disk is None:disk=TARGET_NAME
    root=(Path('/sys/class/block')/disk).resolve(strict=True);result=[]
    for entry in Path('/sys/class/block').iterdir():
        try:
            physical=entry.resolve(strict=True)
            if physical.parent!=root or not (entry/'partition').is_file():continue
            result.append({'name':entry.name,'rdev':field(entry/'dev'),
                           'partition':int(field(entry/'partition')),'sysfs':str(physical)})
        except FileNotFoundError:raise RuntimeError('block inventory changed during partition scan')
    return sorted(result,key=lambda v:v['partition'])


def holders(names):
    result={}
    for name in names:
        d=Path('/sys/class/block')/name/'holders'
        require(d.is_dir(),'holder information unavailable')
        result[name]=sorted(p.name for p in d.iterdir())
    return result


def unescape(text):
    return re.sub(r'\\([0-7]{3})',lambda m:chr(int(m.group(1),8)),text)


def mount_table(content=None):
    lines=Path('/proc/self/mountinfo').read_text().splitlines() if content is None else content.splitlines()
    allmount=[]
    for line in lines:
        left,sep,right=line.partition(' - ');a=left.split();b=right.split()
        require(sep and len(a)>=6 and len(b)>=3,'unparseable mountinfo')
        row={'id':int(a[0]),'parent':int(a[1]),'rdev':a[2],
             'root':unescape(a[3]),'mountpoint':unescape(a[4]),'options':a[5],
             'propagation':a[6:],'fstype':b[0],'source':unescape(b[1])}
        allmount.append(row)
    return allmount


def mounts_for(devices,content=None):
    allmount=mount_table(content);selected=[row for row in allmount if row['rdev'] in devices]
    protected=('/','/boot','/mnt/hdd','/run','/dev','/proc','/sys')
    for row in selected:
        mount=os.path.normpath(row['mountpoint'])
        require(mount.startswith('/') and mount not in protected,'refusing a protected mount')
        require(not any(x.startswith(mount.rstrip('/')+'/') for x in protected),'mount is ancestor of a protected path')
        require(not any(x.get('rdev') not in devices and os.path.normpath(x['mountpoint']).startswith(mount.rstrip('/')+'/') for x in allmount),
                'foreign filesystem nested beneath USB mount')
        require(not any(x.startswith(('shared:','master:','propagate_from:')) for x in row['propagation']),
                'propagated USB mount requires manual audit')
    return sorted(selected,key=lambda v:(-v['mountpoint'].count('/'),v['mountpoint'],v['id']))


def internal_boot_mounts(internal,parts,content=None):
    allowed={internal['rdev'],*[p['rdev'] for p in parts]};rows=mount_table(content);result={}
    for target in ('/boot','/mnt/hdd'):
        found=[row for row in rows if os.path.normpath(row['mountpoint'])==target]
        require(len(found)==1 and found[0]['rdev'] in allowed,
                'internal boot/data mount is not on the known internal disk: '+target)
        require(found[0]['fstype'] not in ('tmpfs','overlay','squashfs'),
                'internal boot/data mount is not persistent: '+target)
        result[target]=found[0]
    return result


def foreign_namespace_mounts(devices):
    own=os.stat('/proc/self/ns/mnt').st_ino;seen={own};result=[]
    for process in Path('/proc').iterdir():
        if not process.name.isdigit():continue
        try:
            namespace=(process/'ns/mnt').stat().st_ino
            if namespace in seen:continue
            text=(process/'mountinfo').read_text();selected=mounts_for(devices,text)
        except FileNotFoundError:continue
        except PermissionError:raise RuntimeError('mount namespace observation denied')
        seen.add(namespace)
        if selected:result.append({'pid':int(process.name),'namespace':namespace,'mounts':selected})
    return result


def target_open_references(devices):
    """Do not unmount target files used by another process, including bindfs."""
    refs=[];own=os.getpid()
    for process in Path('/proc').iterdir():
        if not process.name.isdigit() or int(process.name)==own:continue
        try:
            name=(process/'comm').read_text().strip()
            entries=list((process/'fd').iterdir())
        except FileNotFoundError:continue
        except PermissionError:raise RuntimeError('process file-descriptor observation denied')
        for entry in entries:
            try:item=entry.stat()
            except FileNotFoundError:continue
            except PermissionError:raise RuntimeError('process file-descriptor observation denied')
            number=item.st_rdev if stat.S_ISBLK(item.st_mode) else item.st_dev
            if devpair(number) in devices:
                refs.append({'pid':int(process.name),'kind':'open-target-device-or-file'});break
        if name=='bindfs':
            try:args=(process/'cmdline').read_bytes().split(b'\0')
            except FileNotFoundError:continue
            except PermissionError:raise RuntimeError('bindfs command observation denied')
            for raw in args:
                if not raw.startswith(b'/'):continue
                try:item=os.stat(os.fsdecode(raw))
                except (FileNotFoundError,NotADirectoryError):continue
                except PermissionError:raise RuntimeError('bindfs source observation denied')
                if devpair(item.st_dev) in devices:
                    refs.append({'pid':int(process.name),'kind':'bindfs-source-on-target'});break
    return refs


def swaps_for(devices,content=None):
    lines=Path('/proc/swaps').read_text().splitlines() if content is None else content.splitlines()
    require(lines and lines[0].startswith('Filename'),'unparseable swaps')
    found=[]
    for line in lines[1:]:
        if not line.strip():continue
        name=unescape(line.split()[0]);item=os.stat(name)
        number=item.st_rdev if stat.S_ISBLK(item.st_mode) else item.st_dev
        if devpair(number) in devices:found.append(name)
    return found


def read_exact(fd,offset,length):
    result=bytearray()
    while len(result)<length:
        chunk=os.pread(fd,min(1024*1024,length-len(result)),offset+len(result))
        require(chunk,'short block-device read');result+=chunk
    return bytes(result)


def fd_info(fd,expected):
    st=os.fstat(fd)
    require(stat.S_ISBLK(st.st_mode) and devpair(st.st_rdev)==expected['rdev'],'opened block identity changed')
    require(ioctl_int(fd,BLKGETSIZE64,8)==expected['size_bytes'],'opened size differs')
    require(ioctl_int(fd,BLKGETDISKSEQ,8)==expected['diskseq'],'opened diskseq differs')
    sector=ioctl_int(fd,BLKSSZGET,4)
    require(sector==512 and IMAGE_SIZE%sector==0 and OLD_SIZE%sector==0,
            'unsupported logical sector geometry')
    return sector


def direct_capture_original(fd,sector):
    """Verify the entire .72 ISO and back up every extra byte .75 overwrites."""
    require(EXTRA_SIZE>0 and EXTRA_SIZE%sector==0 and OLD_SIZE%sector==0,'unaligned backup geometry')
    flags=fcntl.fcntl(fd,fcntl.F_GETFL);fcntl.fcntl(fd,fcntl.F_SETFL,flags|os.O_DIRECT)
    try:
        h=hashlib.sha256();position=0
        with mmap.mmap(-1,1024*1024) as buf:
            while position<OLD_SIZE:
                length=min(1024*1024,OLD_SIZE-position);view=memoryview(buf)[:length]
                try:
                    count=os.preadv(fd,[view],position);require(count==length,'short direct preflight read');h.update(view)
                finally:view.release()
                position+=length
        prefix_sha=h.hexdigest()
        with mmap.mmap(-1,EXTRA_SIZE) as buf:
            require(os.preadv(fd,[buf],OLD_SIZE)==EXTRA_SIZE,'short original suffix read')
            suffix=buf[:]
        h.update(suffix)
        def part(offset):
            with mmap.mmap(-1,BACKUP_BYTES) as buf:
                require(os.preadv(fd,[buf],offset)==BACKUP_BYTES,'short direct backup read')
                return buf[:]
        return {'old_prefix_sha256':prefix_sha,'old_overwrite_range_sha256':h.hexdigest(),
                'head':part(0),'tail':part(TARGET_SIZE-BACKUP_BYTES),'suffix':suffix}
    finally:fcntl.fcntl(fd,fcntl.F_SETFL,flags)


def snapshot(include_backup=False):
    require(os.geteuid()==0,'root required')
    require(IDENTITY is not None,'private target identity is required')
    target=device(TARGET_NAME);internal=device(INTERNAL_NAME)
    require(target['size_bytes']==TARGET_SIZE and target['removable']==1 and '/usb' in target['sysfs'].lower(),
            'target is not the specified removable USB disk')
    require(internal['size_bytes']==INTERNAL_SIZE and internal['rdev']!=target['rdev'] and internal['sysfs']!=target['sysfs'],
            'internal disk does not match or overlaps target')
    product=' '.join(field(Path('/sys/class/block')/TARGET_NAME/'device'/x) for x in ('vendor','model'))
    usb=usb_identity();require((usb['vendor_id'],usb['product_id'],usb['serial'])==(USB_VENDOR,USB_PRODUCT,USB_SERIAL),
                               'USB vendor/product/serial differs from the authorized device')
    require(PRODUCT_CONTAINS.upper() in (product+' '+usb['product']).upper(),'USB product identity not confirmed')
    internal_parts=partitions(INTERNAL_NAME);internal_mounts=internal_boot_mounts(internal,internal_parts)
    parts=partitions();allnames=[TARGET_NAME]+[x['name'] for x in parts];held=holders(allnames)
    require(not any(held.values()),'target or partition has holders')
    devices={target['rdev'],*[x['rdev'] for x in parts]};mounts=mounts_for(devices);swaps=swaps_for(devices)
    foreign=foreign_namespace_mounts(devices);require(not foreign,'USB mounted in another mount namespace')
    refs=target_open_references(devices);require(not refs,'USB is open or exposed through bindfs')
    require(not swaps,'target device or filesystem is active swap')
    fd=os.open(TARGET,os.O_RDONLY|os.O_CLOEXEC|os.O_NOFOLLOW)
    try:sector=fd_info(fd,target)
    finally:os.close(fd)
    require(device(TARGET_NAME)==target and usb_identity()==usb and partitions()==parts,'USB changed while being observed')
    value={'identity':dict(IDENTITY),'boot_id':field('/proc/sys/kernel/random/boot_id'),'firmware_mode':'UEFI' if Path('/sys/firmware/efi').is_dir() else 'BIOS',
           'target':target,'internal':internal,'usb':usb,'product':product,'logical_sector':sector,
           'internal_partitions':internal_parts,'internal_mounts':internal_mounts,
           'partitions':parts,'holders':held,'mounts':mounts,'foreign_namespace_mounts':foreign,
           'open_references':refs,'swaps':swaps}
    if include_backup:
        fd=os.open(TARGET,os.O_RDONLY|os.O_CLOEXEC|os.O_NOFOLLOW)
        try:
            fd_info(fd,target);captured=direct_capture_original(fd,sector)
            require(captured['old_prefix_sha256']==OLD_SHA,'USB does not contain the exact .72 ISO')
            require(device(TARGET_NAME)==target and usb_identity()==usb and partitions()==parts,
                    'USB changed during full-image preflight')
        finally:os.close(fd)
        head,tail,suffix=(captured[k] for k in ('head','tail','suffix'))
        value['transaction']=uuid.uuid4().hex
        value['backup']={'head_bytes':len(head),'tail_offset':TARGET_SIZE-BACKUP_BYTES,'tail_bytes':len(tail),
             'suffix_offset':OLD_SIZE,'suffix_bytes':len(suffix),'head_sha256':digest(head),'tail_sha256':digest(tail),
             'suffix_sha256':digest(suffix),'old_prefix_sha256':captured['old_prefix_sha256'],
             'old_overwrite_range_sha256':captured['old_overwrite_range_sha256'],
             'head_base64':base64.b64encode(head).decode(),'tail_base64':base64.b64encode(tail).decode(),
             'suffix_base64':base64.b64encode(suffix).decode()}
    return value


def comparable(a,b):
    for key in ('identity','boot_id','firmware_mode','target','internal','usb','product','logical_sector','internal_partitions',
                'internal_mounts','partitions','holders','mounts','foreign_namespace_mounts','open_references','swaps'):
        require(a[key]==b[key],'preflight changed: '+key)


def restore_preflight(original):
    """Permit later restore only after an internal boot and exact .75 readback."""
    require(not STATE.exists() and not STATE.is_symlink(),
            'current boot has a journal; use the same-boot receipt or inspect it')
    require(original['backup']['old_prefix_sha256']==OLD_SHA,'original backup is not .72')
    prior=original['usb']
    require((prior['vendor_id'],prior['product_id'],prior['serial'])==(USB_VENDOR,USB_PRODUCT,USB_SERIAL),
            'original receipt belongs to another USB')
    now=snapshot();fd=os.open(TARGET,os.O_RDONLY|os.O_CLOEXEC|os.O_NOFOLLOW)
    try:
        sector=fd_info(fd,now['target']);captured=direct_capture_original(fd,sector)
        require(captured['old_overwrite_range_sha256']==IMAGE_SHA,'current USB is not the complete .75 image')
        require(digest(captured['tail'])==original['backup']['tail_sha256'],'untouched disk tail differs')
    finally:os.close(fd)
    comparable(now,snapshot())
    now['transaction']=uuid.uuid4().hex
    now['backup']=original['backup']
    now['restore_mode']='verified075_after_reboot'
    now['current_image_sha256']=IMAGE_SHA
    return now


def journal(value,first=False):
    raw=(json.dumps(value,sort_keys=True)+'\n').encode()
    if first:
        fd=os.open(STATE,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
        with os.fdopen(fd,'wb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
    else:
        require(STATE.is_file() and not STATE.is_symlink(),'operation journal missing')
        temp=STATE.with_name('.'+STATE.name+'.'+uuid.uuid4().hex)
        fd=os.open(temp,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
        try:
            with os.fdopen(fd,'wb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
            os.replace(temp,STATE)
        finally:temp.unlink(missing_ok=True)


def tmpfs_ready():
    require(not Path('/dev/shm').is_symlink(),'temporary staging path indirect')
    entries=Path('/proc/self/mountinfo').read_text().splitlines()
    require(any(' - tmpfs ' in x and unescape(x.split()[4])=='/dev/shm' for x in entries),'temporary staging is not tmpfs')
    require(any(' - tmpfs ' in x and unescape(x.split()[4])=='/run' for x in entries),'operation journal is not on tmpfs')
    s=os.statvfs('/dev/shm');require(s.f_bavail*s.f_frsize>=IMAGE_SIZE+256*1024*1024,'insufficient tmpfs capacity')
    avail=next((int(x.split()[1])*1024 for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')),0)
    require(avail>=IMAGE_SIZE+256*1024*1024,'insufficient available RAM')


def receive(expected_sha):
    tmpfs_ready();path=Path('/dev/shm')/('daphile-live-075-'+uuid.uuid4().hex+'.img')
    fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600);remaining=IMAGE_SIZE;h=hashlib.sha256()
    try:
        with os.fdopen(fd,'wb') as out:
            while remaining:
                block=sys.stdin.buffer.read(min(1024*1024,remaining));require(block,'incomplete ISO transfer')
                out.write(block);h.update(block);remaining-=len(block)
            out.flush();os.fsync(out.fileno())
        require(h.hexdigest()==expected_sha,'incoming image SHA256 mismatch')
        return path
    except BaseException:
        path.unlink(missing_ok=True);raise


def direct_hash(fd,length):
    flags=fcntl.fcntl(fd,fcntl.F_GETFL);fcntl.fcntl(fd,fcntl.F_SETFL,flags|os.O_DIRECT)
    try:
        check=hashlib.sha256();position=0
        with mmap.mmap(-1,1024*1024) as buffer:
            while position<length:
                amount=min(1024*1024,length-position);view=memoryview(buffer)[:amount]
                try:
                    count=os.preadv(fd,[view],position);require(count==amount,'short direct readback');check.update(view)
                finally:view.release()
                position+=amount
        return check.hexdigest()
    finally:fcntl.fcntl(fd,fcntl.F_SETFL,flags)


def stable_identity(expected,now):
    for key in ('identity','boot_id','firmware_mode','target','internal','usb','product','logical_sector',
                'internal_partitions','internal_mounts'):
        require(now[key]==expected[key],'pre-write identity changed: '+key)


def unmount_target(expected,current):
    for item in current['mounts']:
        now=snapshot();stable_identity(expected,now)
        require(any(m['id']==item['id'] and m['mountpoint']==item['mountpoint'] and m['rdev']==item['rdev'] for m in now['mounts']),
                'USB mount changed before unmount')
        p=subprocess.run(['umount','--',item['mountpoint']],capture_output=True,timeout=30)
        require(p.returncode==0,'explicit USB partition unmount failed')
    after=snapshot();stable_identity(expected,after);require(not after['mounts'],'USB still mounted')
    return after


def require_quiet_target(target,parts):
    """Recheck exposed mounts, swaps, users and partition identity before I/O."""
    require(partitions()==parts,'USB partition inventory changed')
    devices={target['rdev'],*[item['rdev'] for item in parts]}
    require(not mounts_for(devices),'USB remounted before write')
    require(not foreign_namespace_mounts(devices),'USB appeared in another mount namespace')
    require(not swaps_for(devices),'USB became active swap')
    require(not target_open_references(devices),'USB became open or exposed through bindfs')


def write_image(expected,operation='write'):
    require(operation in ('write','restore'),'unknown operation')
    require(isinstance(expected.get('transaction'),str) and re.fullmatch('[0-9a-f]{32}',expected['transaction']),
            'invalid preflight transaction')
    backup=expected['backup'];before=snapshot()
    tmpfs_ready()
    if operation=='write':
        comparable(expected,before)
        require(not STATE.exists() and not STATE.is_symlink(),'previous write attempt requires explicit audit')
        record={'boot_id':before['boot_id'],'target':before['target'],'transaction':expected['transaction'],
                'status':'PREPARING_WRITE','bytes_written':0,'iso_sha256':IMAGE_SHA}
        journal(record,first=True);stage_sha=IMAGE_SHA
    else:
        if expected.get('restore_mode')=='verified075_after_reboot':
            comparable(expected,before)
            require(not STATE.exists() and not STATE.is_symlink(),'current boot already has a journal')
            record={'boot_id':before['boot_id'],'target':before['target'],'transaction':expected['transaction'],
                    'status':'PREPARING_RESTORE','bytes_written':0,'iso_sha256':IMAGE_SHA,
                    'restore_mode':'verified075_after_reboot'}
            journal(record,first=True)
        else:
            stable_identity(expected,before)
            require(STATE.is_file() and not STATE.is_symlink(),'same-boot write journal unavailable')
            record=json.loads(STATE.read_text())
            require(record.get('transaction')==expected['transaction'] and record.get('boot_id')==before['boot_id']
                    and record.get('target')==before['target'],'write journal identity differs')
            require(record.get('status') in ('WRITE_VERIFIED','FAILED_NO_AUTORETRY','WRITING','FLUSHED_VERIFYING'),
                    'journal state is not restorable without audit')
            record.update(status='PREPARING_RESTORE',bytes_written=0);journal(record)
        stage_sha=backup['old_overwrite_range_sha256']
    staged=None;fd=None
    try:
        staged=receive(stage_sha)
        fresh=snapshot()
        if operation=='write' or expected.get('restore_mode')=='verified075_after_reboot':comparable(expected,fresh)
        else:stable_identity(expected,fresh)
        record['status']='STAGED_VERIFIED' if operation=='write' else 'RESTORE_STAGED';journal(record)
        after=unmount_target(expected,fresh)
        fd=os.open(TARGET,os.O_RDWR|os.O_EXCL|os.O_CLOEXEC|os.O_NOFOLLOW)
        sector=fd_info(fd,expected['target'])
        require(device(TARGET_NAME)==expected['target'] and usb_identity()==expected['usb'],'USB changed after exclusive open')
        require_quiet_target(after['target'],after['partitions'])
        original=direct_capture_original(fd,sector)
        require(digest(original['tail'])==backup['tail_sha256'],'untouched disk tail changed')
        if operation=='write':
            require(original['old_prefix_sha256']==OLD_SHA and
                    original['old_overwrite_range_sha256']==backup['old_overwrite_range_sha256'] and
                    digest(original['head'])==backup['head_sha256'] and
                    digest(original['suffix'])==backup['suffix_sha256'],
                    'original .72 or backed-up suffix changed before write')
        elif expected.get('restore_mode')=='verified075_after_reboot':
            require(original['old_overwrite_range_sha256']==IMAGE_SHA,
                    'current .75 changed after the restore preflight')
        require_quiet_target(after['target'],after['partitions'])
        record.update(status='WRITING' if operation=='write' else 'RESTORING',bytes_written=0);journal(record)
        h=hashlib.sha256();position=0
        with staged.open('rb') as source:
            while position<IMAGE_SIZE:
                block=source.read(min(1024*1024,IMAGE_SIZE-position));require(block,'staged image became short')
                h.update(block);done=0
                while done<len(block):
                    count=os.pwrite(fd,block[done:],position+done);require(count>0,'short device write');done+=count
                    record['bytes_written']=position+done
                position+=len(block);record['bytes_written']=position
                if position%(16*1024*1024)==0:journal(record)
        require(h.hexdigest()==stage_sha,'staged image changed while writing')
        os.fsync(fd);fcntl.ioctl(fd,BLKFLSBUF)
        record['status']='FLUSHED_VERIFYING' if operation=='write' else 'RESTORE_VERIFYING';journal(record)
        actual=direct_hash(fd,IMAGE_SIZE);require(actual==stage_sha,'direct readback SHA256 mismatch')
        require(fd_info(fd,expected['target'])==sector and device(TARGET_NAME)==expected['target'] and usb_identity()==expected['usb'],
                'USB identity changed during readback')
        if operation=='restore':
            restored=direct_capture_original(fd,sector)
            require(restored['old_prefix_sha256']==OLD_SHA and restored['old_overwrite_range_sha256']==stage_sha and
                    digest(restored['suffix'])==backup['suffix_sha256'] and digest(restored['tail'])==backup['tail_sha256'],
                    'restored .72, suffix or untouched disk tail differs')
        record.update(status='WRITE_VERIFIED' if operation=='write' else 'RESTORE_VERIFIED',
                      bytes_written=IMAGE_SIZE,readback_sha256=actual,verification='fsync BLKFLSBUF O_DIRECT')
        journal(record);return record
    except BaseException as exc:
        if STATE.exists():
            record.update(status='FAILED_NO_AUTORETRY' if operation=='write' else 'RESTORE_FAILED_NO_AUTORETRY',
                          error=type(exc).__name__+': '+str(exc)[:400])
            try:journal(record)
            except Exception:pass
        raise
    finally:
        if fd is not None:os.close(fd)
        if staged is not None:staged.unlink(missing_ok=True)


def main():
    require(len(sys.argv) in (2,3),'action required')
    if sys.argv[1]=='preflight':
        require(len(sys.argv)==3,'private identity required')
        configure_identity(json.loads(sys.argv[2]));value=snapshot(include_backup=True)
    elif sys.argv[1]=='restore-preflight':
        require(len(sys.argv)==3,'original preflight receipt required')
        original=json.loads(sys.argv[2]);configure_identity(original['identity']);value=restore_preflight(original)
    elif sys.argv[1] in ('write','restore'):
        require(len(sys.argv)==3,'preflight receipt required')
        expected=json.loads(sys.argv[2]);configure_identity(expected['identity']);value=write_image(expected,sys.argv[1])
    else:raise RuntimeError('unknown action')
    print(json.dumps(value,sort_keys=True),flush=True)


if __name__=='__main__':
    try:main()
    except BaseException as exc:
        print(json.dumps({'status':'FAILED_NO_AUTORETRY','error':type(exc).__name__+': '+str(exc)[:400]}),flush=True)
        raise SystemExit(1)
