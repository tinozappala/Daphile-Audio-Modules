"""Round-trip the exact .72 and .75 ISOs through a synthetic regular file.

Linux direct I/O and fsync are real. Block-node identity and BLKFLSBUF are
simulated because no real or loop block devices are accessed.
"""
import contextlib
import copy
import hashlib
import json
import os
from pathlib import Path
import shutil
import tempfile
from unittest import mock

import usb_remote_075 as r

r.configure_identity({'target_name':'sdb','internal_name':'sda','target_size':2*1024**3,
 'internal_size':3*1024**3,'usb_vendor':'1234','usb_product':'abcd',
 'usb_serial':'SYNTHETIC','product_contains':'USB DISK'})

OLD=Path('/mnt/c/Build/Daphile-Kernel/iso-0472-d5e4c2d9/Daphile-0.4.72-isolated-live-v2-trial.iso')
NEW=Path('/mnt/c/Build/Daphile-Kernel/iso_candidate_075_live_install/Daphile-0.4.75-live-install-candidate.iso')
OUT=Path('/mnt/c/Build/Daphile-Kernel/usb_writer_075_fixture_final3/EXACT_IMAGE_RESULT.json')


def sha(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()


if OUT.exists():raise RuntimeError('retain existing fixture result')
if sha(OLD)!=r.OLD_SHA or sha(NEW)!=r.IMAGE_SHA:raise RuntimeError('source ISO differs')
root=Path(tempfile.mkdtemp(prefix='darc-usb075-exact-',dir='/root'));disk=root/'disk.img';sentinel=root/'internal.img'
print('phase: create synthetic disk from exact .72',flush=True)
shutil.copyfile(OLD,disk);suffix=(b'ORIGINAL-SUFFIX-'*256)[:r.EXTRA_SIZE]
if len(suffix)!=r.EXTRA_SIZE:raise RuntimeError('fixture suffix length')
tail=(b'OUTSIDE-REGION-SENTINEL-'*4096)
with disk.open('ab') as f:
    f.write(suffix)
    for _ in range(128):f.write(tail)
sentinel.write_bytes(b'INTERNAL-DISK-NOT-TOUCH')
original_sha=sha(disk);sentinel_sha=sha(sentinel);target_size=disk.stat().st_size
print('phase: verify exact .72 and saved suffix using real direct I/O',flush=True)
with mock.patch.object(r,'TARGET_SIZE',target_size):
    fd=os.open(disk,os.O_RDONLY)
    try:before=r.direct_capture_original(fd,512)
    finally:os.close(fd)
if before['old_prefix_sha256']!=r.OLD_SHA or before['suffix']!=suffix:raise RuntimeError('original capture differs')
target={'rdev':'8:16','diskseq':101};internal={'rdev':'8:0','diskseq':99};usb={'serial':'synthetic'}
expected={'identity':dict(r.IDENTITY),'transaction':'b'*32,'boot_id':'fixture','firmware_mode':'UEFI','target':target,'internal':internal,
 'usb':usb,'product':'USB DISK','logical_sector':512,'internal_partitions':[],
 'internal_mounts':{},'partitions':[],'holders':{},'mounts':[],
 'foreign_namespace_mounts':[],'open_references':[],'swaps':[],
 'backup':{'head_sha256':hashlib.sha256(before['head']).hexdigest(),
           'tail_sha256':hashlib.sha256(before['tail']).hexdigest(),
           'suffix_sha256':hashlib.sha256(suffix).hexdigest(),
           'old_overwrite_range_sha256':before['old_overwrite_range_sha256']}}
real_open=os.open
def fake_open(path,flags,mode=0o777):return real_open(disk if str(path)==r.TARGET else path,flags,mode)
stage_write=root/'stage-write';stage_restore=root/'stage-restore'
shutil.copyfile(NEW,stage_write);shutil.copyfile(OLD,stage_restore)
with stage_restore.open('ab') as f:f.write(suffix)
with contextlib.ExitStack() as stack:
    stack.enter_context(mock.patch.object(r,'TARGET_SIZE',target_size))
    stack.enter_context(mock.patch.object(r,'STATE',root/'journal.json'))
    stack.enter_context(mock.patch.object(r,'snapshot',side_effect=lambda:copy.deepcopy(expected)))
    stack.enter_context(mock.patch.object(r,'fd_info',return_value=512))
    stack.enter_context(mock.patch.object(r,'device',return_value=target))
    stack.enter_context(mock.patch.object(r,'usb_identity',return_value=usb))
    stack.enter_context(mock.patch.object(r,'tmpfs_ready'))
    stack.enter_context(mock.patch.object(r,'require_quiet_target'))
    stack.enter_context(mock.patch.object(r.os,'open',side_effect=fake_open))
    stack.enter_context(mock.patch.object(r.fcntl,'ioctl',return_value=0))
    print('phase: write and read back exact .75',flush=True)
    with mock.patch.object(r,'receive',return_value=stage_write):write=r.write_image(expected,'write')
    if write['status']!='WRITE_VERIFIED' or write['readback_sha256']!=r.IMAGE_SHA:raise RuntimeError('write verification failed')
    if sha(sentinel)!=sentinel_sha:raise RuntimeError('internal synthetic sentinel changed')
    print('phase: restore and read back exact .72 plus original suffix',flush=True)
    with mock.patch.object(r,'receive',return_value=stage_restore):restored=r.write_image(expected,'restore')
    if restored['status']!='RESTORE_VERIFIED' or sha(disk)!=original_sha:raise RuntimeError('restored synthetic disk differs')
if sha(sentinel)!=sentinel_sha or sha(OLD)!=r.OLD_SHA or sha(NEW)!=r.IMAGE_SHA:raise RuntimeError('source or sentinel changed')
result={'status':'PASS','scope':'synthetic regular files; Linux direct read and fsync real; block identity and ioctl simulated',
        'old_iso_sha256':r.OLD_SHA,'new_iso_sha256':r.IMAGE_SHA,'synthetic_disk_sha256_before':original_sha,
        'synthetic_disk_sha256_after_restore':sha(disk),'internal_sentinel_sha256_before':sentinel_sha,
        'internal_sentinel_sha256_after':sha(sentinel),'old_suffix_bytes':len(suffix),
        'old_suffix_sha256':hashlib.sha256(suffix).hexdigest(),
        'write_status':write['status'],'write_readback_sha256':write['readback_sha256'],
        'restore_status':restored['status'],'restore_readback_sha256':restored['readback_sha256'],
        'journal_status':json.loads((root/'journal.json').read_text())['status']}
OUT.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2),flush=True)
