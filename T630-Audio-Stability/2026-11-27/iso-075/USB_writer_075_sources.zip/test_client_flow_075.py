"""Exercise client receipts and SSH streaming with an in-memory fake channel."""
import base64
import copy
import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest import mock

import usb_writer_075 as c


class Channel:
    def __init__(self):self.data=bytearray();self.command=None
    def exec_command(self,command):self.command=command
    def shutdown_write(self):pass
    def settimeout(self,timeout):pass
    def sendall(self,data):self.data.extend(data)


class Client:
    def __init__(self):self.channel=Channel()
    def get_transport(self):return self
    def open_session(self,timeout):return self.channel
    def close(self):pass


class ClientFlow(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup);self.root=Path(self.temp.name)
        self.old=b'A'*1024;self.suffix=b'S'*512;self.new=b'B'*1536
        self.oldpath=self.root/'old.iso';self.oldpath.write_bytes(self.old)
        self.newpath=self.root/'new.iso';self.newpath.write_bytes(self.new)
        self.remote=self.root/'remote.py';self.remote.write_text('fixture')
        self.identity={'target_name':'sdb','internal_name':'sda','target_size':2*1024**3,
                       'internal_size':3*1024**3,'usb_vendor':'1234','usb_product':'abcd',
                       'usb_serial':'SYNTHETIC','product_contains':'USB DISK'}
        self.identity_path=self.root/'target.private.json';self.identity_path.write_text(json.dumps(self.identity))
        self.receipt=self.root/'preflight.private.json';self.backup=self.root/'backup.private.bin'
        self.client=Client();self.calls=[]
        self.stack=__import__('contextlib').ExitStack();self.addCleanup(self.stack.close)
        for name,value in [('WORKSPACE',self.root),('OLD',self.oldpath),('ISO',self.newpath),('REMOTE',self.remote),
          ('OLD_SIZE',1024),('EXTRA_SIZE',512),('IMAGE_SIZE',1536),
          ('OLD_SHA',hashlib.sha256(self.old).hexdigest()),('IMAGE_SHA',hashlib.sha256(self.new).hexdigest())]:
            self.stack.enter_context(mock.patch.object(c,name,value))
        self.stack.enter_context(mock.patch.object(c,'connect',side_effect=lambda credential:self.client))
        def command(action,receipt=None):self.calls.append((action,receipt));return action
        self.stack.enter_context(mock.patch.object(c,'remote_command',side_effect=command))

    def observed(self):
        head=b'H'*512;tail=b'T'*512;suffix=self.suffix
        return {'identity':self.identity,'boot_id':'boot','firmware_mode':'UEFI','target':{'rdev':'8:16'},'usb':{'serial':'fixture'},
          'partitions':[],'mounts':[],'holders':{},'swaps':[],
          'backup':{'head_bytes':len(head),'tail_bytes':len(tail),'suffix_bytes':len(suffix),'suffix_offset':1024,
            'head_sha256':hashlib.sha256(head).hexdigest(),'tail_sha256':hashlib.sha256(tail).hexdigest(),
            'suffix_sha256':hashlib.sha256(suffix).hexdigest(),'old_prefix_sha256':hashlib.sha256(self.old).hexdigest(),
            'old_overwrite_range_sha256':hashlib.sha256(self.old+suffix).hexdigest(),
            'head_base64':base64.b64encode(head).decode(),'tail_base64':base64.b64encode(tail).decode(),
            'suffix_base64':base64.b64encode(suffix).decode()}}

    def make_preflight(self):
        with mock.patch.object(c,'read_result',return_value=self.observed()):
            result=c.preflight('credential',self.identity_path,self.receipt,self.backup)
        self.assertEqual(result['status'],'PREFLIGHT_READONLY_VERIFIED')
        self.assertEqual(self.backup.read_bytes(),b'H'*512+b'T'*512+self.suffix)

    def test_preflight_write_and_same_boot_restore_stream_expected_bytes(self):
        self.make_preflight();self.client=Client()
        with mock.patch.object(c,'read_result',return_value={'status':'WRITE_VERIFIED','bytes_written':1536,
              'readback_sha256':hashlib.sha256(self.new).hexdigest(),'verification':'fixture'}):
            result=c.write('credential',self.receipt,self.root/'write.private.json','write')
        self.assertEqual(result['status'],'WRITE_VERIFIED');self.assertEqual(bytes(self.client.channel.data),self.new)
        self.assertEqual(self.calls[-1][0],'write');self.client=Client()
        with mock.patch.object(c,'read_result',return_value={'status':'RESTORE_VERIFIED','bytes_written':1536,
              'readback_sha256':hashlib.sha256(self.old+self.suffix).hexdigest(),'verification':'fixture'}):
            result=c.write('credential',self.receipt,self.root/'restore.private.json','restore')
        self.assertEqual(result['status'],'RESTORE_VERIFIED')
        self.assertEqual(bytes(self.client.channel.data),self.old+self.suffix);self.assertEqual(self.calls[-1][0],'restore')

    def test_restore_preflight_keeps_backup_path_local(self):
        self.make_preflight();self.client=Client()
        reply={'restore_mode':'verified075_after_reboot','current_image_sha256':hashlib.sha256(self.new).hexdigest(),
               'boot_id':'new-boot','target':{'rdev':'8:16'}}
        with mock.patch.object(c,'read_result',return_value=reply):
            result=c.restore_preflight('credential',self.receipt,self.root/'restore-preflight.private.json')
        self.assertEqual(result['status'],'RESTORE_PREFLIGHT_VERIFIED')
        action,sent=self.calls[-1];self.assertEqual(action,'restore-preflight')
        self.assertNotIn('local_path',sent['backup']);self.assertNotIn('combined_sha256',sent['backup'])


if __name__=='__main__':unittest.main(verbosity=2)
