"""Offline guard and backup tests; no block devices or network."""
import copy
import hashlib
import os
from pathlib import Path
import posixpath
import stat
import tempfile
import types
import unittest
from unittest import mock

import usb_remote_075 as remote
import usb_writer_075 as client

FIXTURE_IDENTITY={'target_name':'sdb','internal_name':'sda','target_size':2*1024**3,
 'internal_size':3*1024**3,'usb_vendor':'1234','usb_product':'abcd',
 'usb_serial':'SYNTHETIC','product_contains':'USB DISK'}
remote.configure_identity(FIXTURE_IDENTITY)


class IdentityAndMountTests(unittest.TestCase):
    def setUp(self):
        p=mock.patch.object(remote.os.path,'normpath',side_effect=posixpath.normpath)
        p.start();self.addCleanup(p.stop)

    def test_internal_boot_and_data_must_belong_to_internal_disk(self):
        disk={'rdev':'8:0'};parts=[{'rdev':'8:1'},{'rdev':'8:2'}]
        good=('1 0 8:1 / /boot ro - ext4 /dev/sda1 ro\n'
              '2 0 8:2 / /mnt/hdd rw - ext4 /dev/sda2 rw\n')
        self.assertEqual(set(remote.internal_boot_mounts(disk,parts,good)),{'/boot','/mnt/hdd'})
        for bad in (good.replace('8:2','8:17'),good.replace('ext4 /dev/sda2','tmpfs none'),
                    good.replace('/mnt/hdd','/different')):
            with self.subTest(bad=bad),self.assertRaises(RuntimeError):remote.internal_boot_mounts(disk,parts,bad)

    def test_protected_or_foreign_nested_target_mounts_fail_closed(self):
        for text in ('1 0 8:17 / /mnt/hdd rw - ext4 /dev/sdb1 rw\n',
                     '1 0 8:17 / /media/u rw - ext4 /dev/sdb1 rw\n2 1 8:1 / /media/u/other rw - ext4 /dev/sda1 rw\n',
                     '1 0 8:17 / /media/u rw shared:7 - ext4 /dev/sdb1 rw\n'):
            with self.subTest(text=text),self.assertRaises(RuntimeError):remote.mounts_for({'8:17'},text)

    def test_wrong_usb_serial_is_refused_before_open(self):
        target={'size_bytes':remote.TARGET_SIZE,'removable':1,'sysfs':'/sys/devices/usb/sdb','rdev':'8:16'}
        internal={'size_bytes':remote.INTERNAL_SIZE,'rdev':'8:0','sysfs':'/sys/devices/ata/sda'}
        usb={'vendor_id':remote.USB_VENDOR,'product_id':remote.USB_PRODUCT,'serial':'wrong','product':'USB DISK'}
        with mock.patch.object(remote.os,'geteuid',return_value=0,create=True),mock.patch.object(remote,'device',side_effect=[target,internal]), \
             mock.patch.object(remote,'field',return_value='USB DISK'),mock.patch.object(remote,'usb_identity',return_value=usb), \
             mock.patch.object(remote.os,'open') as opened:
            with self.assertRaisesRegex(RuntimeError,'vendor/product/serial'):remote.snapshot()
            opened.assert_not_called()

    def test_any_identity_change_refuses_comparison(self):
        keys=('identity','boot_id','firmware_mode','target','internal','usb','product','logical_sector','internal_partitions',
              'internal_mounts','partitions','holders','mounts','foreign_namespace_mounts','open_references','swaps')
        baseline={key:key for key in keys}
        for key in keys:
            changed=baseline.copy();changed[key]='changed'
            with self.subTest(key=key),self.assertRaisesRegex(RuntimeError,'preflight changed'):remote.comparable(baseline,changed)

    def test_bindfs_source_on_target_is_reported(self):
        with tempfile.TemporaryDirectory() as tmp:
            proc=Path(tmp)/'proc';p=proc/'123';(p/'fd').mkdir(parents=True)
            (p/'comm').write_text('bindfs\n')
            (p/'cmdline').write_bytes(b'bindfs\0/synthetic/usb-source\0/synthetic/alias\0')
            real_path=Path;real_stat=os.stat
            def choose(value):return proc if value=='/proc' else real_path(value)
            def fake_stat(value,*args,**kwargs):
                if str(value)=='/synthetic/usb-source':return types.SimpleNamespace(st_dev=17)
                if str(value)=='/synthetic/alias':return types.SimpleNamespace(st_dev=99)
                return real_stat(value,*args,**kwargs)
            with mock.patch.object(remote,'Path',side_effect=choose),mock.patch.object(remote.os,'stat',side_effect=fake_stat), \
                 mock.patch.object(remote,'devpair',side_effect=lambda value:'8:17' if value==17 else '0:99'):
                self.assertEqual(remote.target_open_references({'8:17'}),[{'pid':123,'kind':'bindfs-source-on-target'}])

    def test_quiet_recheck_rejects_new_activity_or_partition_change(self):
        target={'rdev':'8:16'};parts=[{'rdev':'8:17'}]
        checks={'partitions':parts,'mounts_for':[],'foreign_namespace_mounts':[],
                'swaps_for':[],'target_open_references':[]}
        for name in checks:
            altered=copy.deepcopy(checks);altered[name]=['changed']
            with self.subTest(name=name),__import__('contextlib').ExitStack() as stack:
                for key,value in altered.items():stack.enter_context(mock.patch.object(remote,key,return_value=value))
                with self.assertRaises(RuntimeError):remote.require_quiet_target(target,parts)

    def test_private_identity_rejects_overlap_and_invalid_serial(self):
        for change in ({'target_name':'sda'},{'usb_serial':''},{'target_size':True},
                       {'target_name':'../../device'},{'usb_vendor':'not-hex'}):
            value=dict(FIXTURE_IDENTITY,**change)
            with self.subTest(change=change),self.assertRaises(RuntimeError):remote.configure_identity(value)


class LocalBackupTests(unittest.TestCase):
    def test_backup_suffix_and_local_old_image_are_required(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);old=root/'old.iso';old.write_bytes(b'A'*1024);backup=root/'backup.private.bin'
            head=b'H'*512;tail=b'T'*512;suffix=b'S'*512;backup.write_bytes(head+tail+suffix)
            info={'local_path':str(backup),'combined_sha256':hashlib.sha256(backup.read_bytes()).hexdigest(),
                  'head_bytes':512,'tail_bytes':512,'suffix_bytes':512,'suffix_offset':1024,
                  'head_sha256':hashlib.sha256(head).hexdigest(),'tail_sha256':hashlib.sha256(tail).hexdigest(),
                  'suffix_sha256':hashlib.sha256(suffix).hexdigest(),
                  'old_overwrite_range_sha256':hashlib.sha256(old.read_bytes()+suffix).hexdigest()}
            with mock.patch.object(client,'WORKSPACE',root),mock.patch.object(client,'OLD',old), \
                 mock.patch.object(client,'OLD_SIZE',1024),mock.patch.object(client,'EXTRA_SIZE',512), \
                 mock.patch.object(client,'OLD_SHA',hashlib.sha256(old.read_bytes()).hexdigest()):
                self.assertEqual(client.backup_parts(info)[2],suffix)
                backup.write_bytes(head+tail+b'X'*512)
                with self.assertRaisesRegex(RuntimeError,'backup changed'):client.backup_parts(info)


if __name__=='__main__':unittest.main(verbosity=2)
