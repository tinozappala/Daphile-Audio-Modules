"""Real Linux file I/O; only synthetic regular files, never block devices."""
import contextlib
import copy
import hashlib
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest import mock

import usb_remote_075 as r

r.configure_identity({'target_name':'sdb','internal_name':'sda','target_size':2*1024**3,
 'internal_size':3*1024**3,'usb_vendor':'1234','usb_product':'abcd',
 'usb_serial':'SYNTHETIC','product_contains':'USB DISK'})


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()


class SyntheticFlow(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(prefix='usb075-small-');self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name);self.target=self.root/'disk.img';self.sentinel=self.root/'internal.img'
        self.old=b'A'*8192;self.extra=b'Z'*4096;self.new=b'B'*12288
        self.target.write_bytes(self.old+self.extra+b'T'*(8*1024*1024));self.sentinel.write_bytes(b'INTERNAL')
        self.original=sha(self.target);self.state=self.root/'journal.json';self.stage_index=0
        target={'rdev':'8:16','diskseq':101};internal={'rdev':'8:0','diskseq':99}
        self.usb={'vendor_id':r.USB_VENDOR,'product_id':r.USB_PRODUCT,'serial':r.USB_SERIAL}
        self.expected={'identity':dict(r.IDENTITY),'transaction':'a'*32,'boot_id':'boot','firmware_mode':'UEFI','target':target,'internal':internal,
          'usb':self.usb,'product':'USB DISK','logical_sector':512,'internal_partitions':[],
          'internal_mounts':{},'partitions':[],'holders':{},'mounts':[],
          'foreign_namespace_mounts':[],'open_references':[],'swaps':[],
          'backup':{'head_sha256':hashlib.sha256((self.old+self.extra)[:4096]).hexdigest(),
                    'tail_sha256':hashlib.sha256(b'T'*4096).hexdigest(),
                    'suffix_sha256':hashlib.sha256(self.extra).hexdigest(),
                    'old_prefix_sha256':hashlib.sha256(self.old).hexdigest(),
                    'old_overwrite_range_sha256':hashlib.sha256(self.old+self.extra).hexdigest()}}
        real_open=os.open
        def file_only(path,flags,mode=0o777):
            return real_open(self.target if str(path)==r.TARGET else path,flags,mode)
        self.stack=contextlib.ExitStack();self.addCleanup(self.stack.close)
        settings=[('STATE',self.state),('OLD_SIZE',len(self.old)),('OLD_SHA',hashlib.sha256(self.old).hexdigest()),
          ('IMAGE_SIZE',len(self.new)),('IMAGE_SHA',hashlib.sha256(self.new).hexdigest()),('EXTRA_SIZE',len(self.extra)),
          ('TARGET_SIZE',self.target.stat().st_size),('BACKUP_BYTES',4096)]
        for name,value in settings:self.stack.enter_context(mock.patch.object(r,name,value))
        for name,value in [('snapshot',lambda:copy.deepcopy(self.expected)),('fd_info',lambda fd,target:512),
                           ('device',lambda name:self.expected['target']),('usb_identity',lambda:self.usb)]:
            self.stack.enter_context(mock.patch.object(r,name,side_effect=value))
        self.stack.enter_context(mock.patch.object(r,'tmpfs_ready'))
        self.stack.enter_context(mock.patch.object(r,'require_quiet_target'))
        self.stack.enter_context(mock.patch.object(r.os,'open',side_effect=file_only))
        self.stack.enter_context(mock.patch.object(r.fcntl,'ioctl',return_value=0))

    def stage(self,data):
        self.stage_index+=1;path=self.root/('stage'+str(self.stage_index));path.write_bytes(data);return path

    def test_partial_write_is_journalled_and_explicit_restore_is_exact(self):
        real_pwrite=os.pwrite;calls=0
        def interrupt(fd,data,offset):
            nonlocal calls
            calls+=1
            if calls==1:return real_pwrite(fd,data[:512],offset)
            raise OSError('synthetic interruption')
        with mock.patch.object(r,'receive',return_value=self.stage(self.new)),mock.patch.object(r.os,'pwrite',side_effect=interrupt):
            with self.assertRaisesRegex(OSError,'synthetic interruption'):r.write_image(self.expected,'write')
        saved=json.loads(self.state.read_text())
        self.assertEqual((saved['status'],saved['bytes_written']),('FAILED_NO_AUTORETRY',512))
        with mock.patch.object(r,'receive') as receive:
            with self.assertRaisesRegex(RuntimeError,'previous write attempt'):r.write_image(self.expected,'write')
            receive.assert_not_called()
        with mock.patch.object(r,'receive',return_value=self.stage(self.old+self.extra)):
            result=r.write_image(self.expected,'restore')
        self.assertEqual(result['status'],'RESTORE_VERIFIED');self.assertEqual(sha(self.target),self.original)
        self.assertEqual(self.sentinel.read_bytes(),b'INTERNAL')

    def test_uncertain_direct_read_fails_before_first_write(self):
        with mock.patch.object(r,'receive',return_value=self.stage(self.new)),mock.patch.object(r,'direct_capture_original',side_effect=OSError('direct I/O refused')):
            with self.assertRaisesRegex(OSError,'direct I/O refused'):r.write_image(self.expected,'write')
        self.assertEqual(sha(self.target),self.original)
        self.assertEqual(json.loads(self.state.read_text())['bytes_written'],0)

    def test_changed_untouched_tail_blocks_restoration(self):
        with mock.patch.object(r,'receive',return_value=self.stage(self.new)):
            self.assertEqual(r.write_image(self.expected,'write')['status'],'WRITE_VERIFIED')
        with self.target.open('r+b') as f:f.seek(-512,2);f.write(b'X'*512)
        before=sha(self.target)
        with mock.patch.object(r,'receive',return_value=self.stage(self.old+self.extra)):
            with self.assertRaisesRegex(RuntimeError,'disk tail changed'):r.write_image(self.expected,'restore')
        self.assertEqual(sha(self.target),before)
        self.assertEqual(json.loads(self.state.read_text())['status'],'RESTORE_FAILED_NO_AUTORETRY')

    def test_fresh_preflight_restores_only_complete_075_after_a_new_boot(self):
        original=copy.deepcopy(self.expected)
        with mock.patch.object(r,'receive',return_value=self.stage(self.new)):
            self.assertEqual(r.write_image(self.expected,'write')['status'],'WRITE_VERIFIED')
        self.state.unlink()  # Isolated test-only simulation of volatile /run after reboot.
        self.expected['boot_id']='new-boot';self.expected['target']['diskseq']=202
        fresh=r.restore_preflight(original)
        self.assertEqual((fresh['restore_mode'],fresh['current_image_sha256']),('verified075_after_reboot',r.IMAGE_SHA))
        with mock.patch.object(r,'receive',return_value=self.stage(self.old+self.extra)):
            self.assertEqual(r.write_image(fresh,'restore')['status'],'RESTORE_VERIFIED')
        self.assertEqual(sha(self.target),self.original);self.assertEqual(self.sentinel.read_bytes(),b'INTERNAL')

    def test_fresh_restore_preflight_refuses_partial_or_unknown_image(self):
        original=copy.deepcopy(self.expected)
        with mock.patch.object(r,'receive',return_value=self.stage(self.new)):
            r.write_image(self.expected,'write')
        self.state.unlink()
        with self.target.open('r+b') as f:f.write(b'X'*512)
        self.expected['boot_id']='new-boot'
        with self.assertRaisesRegex(RuntimeError,'not the complete .75'):r.restore_preflight(original)
        self.assertFalse(self.state.exists())

    def test_old_same_boot_receipt_cannot_be_reused_after_reboot(self):
        original=copy.deepcopy(self.expected);self.expected['boot_id']='new-boot'
        with mock.patch.object(r,'receive') as receive:
            with self.assertRaisesRegex(RuntimeError,'identity changed'):r.write_image(original,'restore')
        receive.assert_not_called();self.assertEqual(sha(self.target),self.original)


if __name__=='__main__':unittest.main(verbosity=2)
