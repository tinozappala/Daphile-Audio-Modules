"""Two-step .72-to-.75 writer and explicit same-boot restore for one USB.

All reports/backups are private local files. The target preflight is read-only;
the separate write command stages the pinned ISO in target RAM before unmount.
"""
import argparse
import base64
import hashlib
import json
import os
from pathlib import Path
import shlex
import sys
import time

HERE=Path(__file__).resolve().parent
WORKSPACE=HERE.parents[1]
ISO=WORKSPACE/'next_audio_20261127/live_usb_install_vm/release_075/Daphile-0.4.75-live-install-candidate.iso'
OLD=WORKSPACE/'next_audio_20261127/iso_consolidata/Daphile-0.4.72-isolated-live-v2-trial.iso'
REMOTE=HERE/'usb_remote_075.py'
OLD_SIZE=808286208
OLD_SHA='d5e4c2d90b722a15be0de5814f5a6d71543d36a52dcc407316eb586126bc8c47'
IMAGE_SIZE=808290304
IMAGE_SHA='76081f0321226e3dac8a8d6fd7f821a340a640c7e35ff2a24497f12742c5abd8'
EXTRA_SIZE=IMAGE_SIZE-OLD_SIZE


def require(value,message):
    if not value:raise RuntimeError(message)


def sha(path):
    with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()


def private_path(path,suffix):
    p=Path(path).absolute();parent=p.parent.resolve(strict=True)
    require(parent.is_relative_to(WORKSPACE.resolve()) and p.name.endswith(suffix),'private output must be inside the workspace with the requested suffix')
    require(not p.exists() and not p.is_symlink(),'private output already exists')
    return p


def create(path,data):
    with Path(path).open('xb') as stream:
        stream.write(data);stream.flush();os.fsync(stream.fileno())
    try:os.chmod(path,0o600)
    except OSError:pass


def connect(credential):
    sys.path.insert(0,str(WORKSPACE/'next_audio_20261127/boot71'))
    from controlled_boot import Adapter
    return Adapter(credential).connect()


def remote_command(action,receipt=None):
    source=REMOTE.read_text(encoding='utf-8')
    cmd='python3 -I -B -c '+shlex.quote(source)+' '+shlex.quote(action)
    if receipt is not None:cmd+=' '+shlex.quote(json.dumps(receipt,sort_keys=True,separators=(',',':')))
    return cmd


def read_result(chan,limit=16*1024*1024,timeout=180):
    data=bytearray();err=bytearray();deadline=time.monotonic()+timeout
    while True:
        if chan.recv_ready():data+=chan.recv(1024*1024)
        if chan.recv_stderr_ready():err+=chan.recv_stderr(65536)
        require(len(data)<=limit and len(err)<=65536,'remote result exceeds bound')
        if chan.exit_status_ready() and not chan.recv_ready() and not chan.recv_stderr_ready():break
        require(time.monotonic()<deadline,'remote response timed out; inspect remote journal before any retry')
        time.sleep(.05)
    rc=chan.recv_exit_status()
    try:value=json.loads(data.decode())
    except Exception:raise RuntimeError('remote result unavailable; inspect remote journal before any retry')
    require(rc==0,'remote refused operation: '+str(value.get('error','unknown failure')))
    return value


def old_image(suffix):
    require(OLD.is_file() and not OLD.is_symlink() and OLD.stat().st_size==OLD_SIZE,
            'the exact local .72 image is unavailable')
    require(len(suffix)==EXTRA_SIZE,'original overwritten suffix has wrong length')
    prefix=hashlib.sha256();whole=hashlib.sha256()
    with OLD.open('rb') as stream:
        while True:
            block=stream.read(1024*1024)
            if not block:break
            prefix.update(block);whole.update(block)
    require(prefix.hexdigest()==OLD_SHA,'the local .72 image differs')
    whole.update(suffix);return whole.hexdigest()


def backup_parts(info):
    candidate=Path(info['local_path'])
    require(not candidate.is_symlink(),'private backup is indirect')
    backup=candidate.resolve(strict=True)
    require(backup.is_relative_to(WORKSPACE.resolve()) and backup.is_file(),
            'private backup is outside workspace or indirect')
    raw=backup.read_bytes()
    require(hashlib.sha256(raw).hexdigest()==info['combined_sha256'],'private backup changed')
    a=info['head_bytes'];b=a+info['tail_bytes'];c=b+info['suffix_bytes']
    require(len(raw)==c and info['suffix_offset']==OLD_SIZE and info['suffix_bytes']==EXTRA_SIZE,
            'backup geometry differs')
    head,tail,suffix=raw[:a],raw[a:b],raw[b:c]
    require(hashlib.sha256(head).hexdigest()==info['head_sha256'] and
            hashlib.sha256(tail).hexdigest()==info['tail_sha256'] and
            hashlib.sha256(suffix).hexdigest()==info['suffix_sha256'],
            'backup contents differ')
    require(old_image(suffix)==info['old_overwrite_range_sha256'],'.72 image plus suffix no longer matches backup')
    return head,tail,suffix


def preflight(credential,identity_path,receipt_path,backup_path):
    receipt=private_path(receipt_path,'.private.json');backup=private_path(backup_path,'.private.bin')
    require(receipt!=backup,'receipt and backup paths overlap')
    identity_file=Path(identity_path)
    require(identity_file.name.endswith('.private.json') and not identity_file.is_symlink(),
            'target identity must be a private direct file')
    identity_file=identity_file.resolve(strict=True)
    require(identity_file.is_relative_to(WORKSPACE.resolve()) and identity_file.is_file(),
            'target identity is outside the private workspace')
    identity_raw=identity_file.read_bytes();require(len(identity_raw)<=16384,'target identity is too large')
    identity=json.loads(identity_raw)
    require(ISO.is_file() and not ISO.is_symlink() and ISO.stat().st_size==IMAGE_SIZE and sha(ISO)==IMAGE_SHA,'approved local ISO differs')
    code_sha=sha(REMOTE);client=connect(credential)
    try:
        chan=client.get_transport().open_session(timeout=15);chan.exec_command(remote_command('preflight',identity));chan.shutdown_write()
        value=read_result(chan,timeout=600)
    finally:client.close()
    require(value.get('identity')==identity,'remote target identity differs')
    info=value['backup'];head=base64.b64decode(info.pop('head_base64'),validate=True);tail=base64.b64decode(info.pop('tail_base64'),validate=True)
    suffix=base64.b64decode(info.pop('suffix_base64'),validate=True)
    require(len(head)==info['head_bytes'] and len(tail)==info['tail_bytes'] and
            len(suffix)==info['suffix_bytes']==EXTRA_SIZE and info['suffix_offset']==OLD_SIZE and
            hashlib.sha256(head).hexdigest()==info['head_sha256'] and hashlib.sha256(tail).hexdigest()==info['tail_sha256'] and
            hashlib.sha256(suffix).hexdigest()==info['suffix_sha256'], 'USB backup integrity failure')
    require(info['old_prefix_sha256']==OLD_SHA and old_image(suffix)==info['old_overwrite_range_sha256'],
            'local .72 plus suffix is not the original overwrite range')
    data=head+tail+suffix;create(backup,data)
    value['backup']['local_path']=str(backup);value['backup']['combined_sha256']=hashlib.sha256(data).hexdigest()
    output={'status':'PREFLIGHT_READONLY_VERIFIED','observed':value,'remote_script_sha256':code_sha,
            'iso_sha256':IMAGE_SHA,'iso_bytes':IMAGE_SIZE,'identity_sha256':hashlib.sha256(identity_raw).hexdigest(),
            'created_epoch_ns':time.time_ns()}
    create(receipt,(json.dumps(output,indent=2,sort_keys=True)+'\n').encode())
    return {'status':output['status'],'receipt':str(receipt),'backup':str(backup),
            'boot_id':value['boot_id'],'firmware_mode':value['firmware_mode'],
            'target':value['target'],'usb':value['usb'],'partitions':value['partitions'],
            'mounts':value['mounts'],'holders':value['holders'],'swaps':value['swaps'],
            'old_iso_sha256':OLD_SHA,'old_overwrite_range_sha256':info['old_overwrite_range_sha256']}


def restore_preflight(credential,receipt_path,restore_receipt_path):
    original_path=Path(receipt_path)
    require(not original_path.is_symlink(),'original receipt is indirect')
    original_path=original_path.resolve(strict=True)
    require(original_path.is_relative_to(WORKSPACE.resolve()),'original receipt outside workspace')
    original_raw=original_path.read_bytes();original=json.loads(original_raw)
    require(original.get('status')=='PREFLIGHT_READONLY_VERIFIED' and original.get('iso_sha256')==IMAGE_SHA and
            original.get('iso_bytes')==IMAGE_SIZE and original.get('remote_script_sha256')==sha(REMOTE),
            'original preflight or script differs')
    restore_receipt=private_path(restore_receipt_path,'.private.json')
    observed=original['observed'];backup_parts(observed['backup'])
    # The local filesystem path and its checksum need not be sent to the device.
    remote_observed=dict(observed);remote_observed['backup']={k:v for k,v in observed['backup'].items()
        if k not in ('local_path','combined_sha256')}
    client=connect(credential)
    try:
        chan=client.get_transport().open_session(timeout=15)
        chan.exec_command(remote_command('restore-preflight',remote_observed));chan.shutdown_write()
        value=read_result(chan,limit=65536,timeout=600)
    finally:client.close()
    require(value.get('restore_mode')=='verified075_after_reboot' and value.get('current_image_sha256')==IMAGE_SHA,
            'remote restore preflight did not verify .75')
    value['backup']=observed['backup']
    output={'status':'RESTORE_PREFLIGHT_VERIFIED','observed':value,'remote_script_sha256':sha(REMOTE),
            'iso_sha256':IMAGE_SHA,'iso_bytes':IMAGE_SIZE,
            'original_preflight_sha256':hashlib.sha256(original_raw).hexdigest(),'created_epoch_ns':time.time_ns()}
    create(restore_receipt,(json.dumps(output,indent=2,sort_keys=True)+'\n').encode())
    return {'status':output['status'],'receipt':str(restore_receipt),'boot_id':value['boot_id'],
            'target':value['target'],'current_iso_sha256':value['current_image_sha256']}


def write(credential,receipt_path,result_path,operation='write'):
    receipt=Path(receipt_path);require(not receipt.is_symlink(),'preflight receipt is indirect')
    receipt=receipt.resolve(strict=True);require(receipt.is_relative_to(WORKSPACE.resolve()),'preflight receipt outside workspace')
    result=private_path(result_path,'.private.json');raw=receipt.read_bytes();original=json.loads(raw)
    allowed=('PREFLIGHT_READONLY_VERIFIED','RESTORE_PREFLIGHT_VERIFIED') if operation=='restore' else ('PREFLIGHT_READONLY_VERIFIED',)
    require(original.get('status') in allowed and original.get('iso_sha256')==IMAGE_SHA and
            original.get('iso_bytes')==IMAGE_SIZE and original.get('remote_script_sha256')==sha(REMOTE),'preflight or script differs')
    require(operation in ('write','restore'),'unknown operation')
    observed=original['observed'];head,tail,suffix=backup_parts(observed['backup'])
    if operation=='write':
        require(ISO.is_file() and not ISO.is_symlink() and ISO.stat().st_size==IMAGE_SIZE and sha(ISO)==IMAGE_SHA,'approved local ISO differs')
    outcome={'status':'DISPATCHED_NO_AUTORETRY','preflight_sha256':hashlib.sha256(raw).hexdigest(),
             'iso_sha256':IMAGE_SHA,'operation':operation,'remote_journal':'/run/daphile-live-usb-write-075.json'}
    create(result,(json.dumps(outcome,indent=2)+'\n').encode())
    client=connect(credential)
    try:
        chan=client.get_transport().open_session(timeout=15);chan.settimeout(60)
        chan.exec_command(remote_command(operation,observed))
        with (ISO if operation=='write' else OLD).open('rb') as stream:
            while True:
                block=stream.read(1024*1024)
                if not block:break
                chan.sendall(block)
        if operation=='restore':chan.sendall(suffix)
        chan.shutdown_write()
        value=read_result(chan,limit=65536,timeout=3600)
        want_status='WRITE_VERIFIED' if operation=='write' else 'RESTORE_VERIFIED'
        want_sha=IMAGE_SHA if operation=='write' else observed['backup']['old_overwrite_range_sha256']
        require(value.get('status')==want_status and value.get('bytes_written')==IMAGE_SIZE and
                value.get('readback_sha256')==want_sha,'remote write/readback not verified')
    finally:client.close()
    require(sha(ISO if operation=='write' else OLD)==(IMAGE_SHA if operation=='write' else OLD_SHA),
            'local source image changed during transfer')
    final={'status':want_status,'preflight_sha256':outcome['preflight_sha256'],'result':value,'iso_sha256':IMAGE_SHA}
    temp=result.with_name('.'+result.name+'.tmp')
    create(temp,(json.dumps(final,indent=2,sort_keys=True)+'\n').encode())
    os.replace(temp,result)
    return {'status':want_status,'result':str(result),'sha256':value['readback_sha256'],'verification':value['verification']}


def main():
    p=argparse.ArgumentParser(description=__doc__);sub=p.add_subparsers(dest='action',required=True)
    a=sub.add_parser('preflight');a.add_argument('--credential-file',type=Path,required=True);a.add_argument('--identity-file',type=Path,required=True);a.add_argument('--receipt',type=Path,required=True);a.add_argument('--backup',type=Path,required=True)
    b=sub.add_parser('write');b.add_argument('--credential-file',type=Path,required=True);b.add_argument('--receipt',type=Path,required=True);b.add_argument('--result',type=Path,required=True)
    c=sub.add_parser('restore');c.add_argument('--credential-file',type=Path,required=True);c.add_argument('--receipt',type=Path,required=True);c.add_argument('--result',type=Path,required=True)
    d=sub.add_parser('restore-preflight');d.add_argument('--credential-file',type=Path,required=True);d.add_argument('--receipt',type=Path,required=True);d.add_argument('--restore-receipt',type=Path,required=True)
    args=p.parse_args()
    if args.action=='preflight':value=preflight(args.credential_file,args.identity_file,args.receipt,args.backup)
    elif args.action=='restore-preflight':value=restore_preflight(args.credential_file,args.receipt,args.restore_receipt)
    else:value=write(args.credential_file,args.receipt,args.result,args.action)
    print(json.dumps(value,indent=2,sort_keys=True))


if __name__=='__main__':
    try:main()
    except Exception as exc:
        print(json.dumps({'status':'FAILED_INSPECT_BEFORE_RETRY','error':type(exc).__name__+': '+str(exc)[:400]}),file=sys.stderr)
        raise SystemExit(1)
