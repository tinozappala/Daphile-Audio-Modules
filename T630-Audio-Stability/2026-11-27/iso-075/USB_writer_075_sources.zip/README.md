# Scrittura della live .75 e ripristino della .72

Questo operatore deriva dal writer .72 e usa una ricevuta privata di preflight,
un'identità USB fornita in un file privato e un journal remoto monouso. I
sorgenti qui presenti non contengono l'identità del dispositivo. L'operazione
richiede che il sistema sia già avviato dalla sua installazione interna e che
la chiavetta contenga esattamente la ISO .72 verificata.

Il preflight legge l'intera immagine .72 con I/O diretto, verifica identità,
dimensioni, seriale, disco interno, mount di boot e dati, partizioni, holder,
swap, namespace e riferimenti aperti; riconosce anche sorgenti bindfs sul
bersaglio. Salva privatamente testa e coda del supporto e i 4096 byte oltre la
fine della .72 che verrebbero sovrascritti dalla .75. La copia locale della
ISO .72, controllata per intero, insieme a quei 4096 byte costituisce il backup
esatto della regione modificata. **Non è un backup completo dell'intero disco.**

La scrittura controlla nuovamente ricevuta, identità e immagine .72, riceve
l'intera .75 in tmpfs e ne verifica l'hash prima di agire. Smonta soltanto
eventuali mount diretti del bersaglio dopo i controlli; se rileva file aperti o
alias bindfs riferiti alla chiavetta, si ferma e richiede un'ispezione. Dopo
l'apertura esclusiva ripete i controlli e rilegge l'immagine precedente prima
del primo byte. Conclude con `fsync`, `BLKFLSBUF` e rilettura integrale
`O_DIRECT` della .75. Non invia comandi alla coda, al player o ai preset.

Il comando `restore` è esplicito e usa la stessa ricevuta durante lo stesso
boot, anche dopo una scrittura interrotta con journal disponibile. Ristadia la
.72 più i 4096 byte salvati e verifica l'intera regione ripristinata. Dopo un
nuovo avvio interno si usa prima `restore-preflight`: questo accetta solo una
.75 **integra**, la stessa identità USB e la coda del disco invariata. Un
supporto parzialmente scritto dopo la perdita del journal richiede ispezione,
non viene riprovato automaticamente. In entrambi i casi la verifica non
costituisce una rilettura integrale dei byte esterni alla regione modificata.

I sottocomandi sono `preflight`, `write`, `restore-preflight` e `restore`.
`preflight` richiede `--credential-file`, `--identity-file`, `--receipt` e
`--backup`; gli altri richiedono credenziali e ricevuta, più `--result` oppure
`--restore-receipt`. Ricevute e backup devono avere nomi privati nuovi nel
workspace. Le istruzioni legate al dispositivo sono conservate separatamente
in un documento privato; non pubblicare identità, credenziali o ricevute reali.

Non è stato individuato nel progetto un writer Windows per dischi fisici già
verificato da riutilizzare, quindi questa consegna non ne introduce uno. Le
prove usano file sintetici su MATTEO: la lettura diretta e `fsync` sono reali,
mentre identità block-device, `BLKFLSBUF` e trasporto SSH sono simulati. Nessun
dispositivo fisico o t630 è stato usato nella preparazione dell'operatore.
