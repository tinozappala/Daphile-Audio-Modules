"""Serve only one private .03 LMS package and index to one selected LAN host."""
import argparse
from http.server import BaseHTTPRequestHandler,HTTPServer
import hashlib
import ipaddress
import json
from pathlib import Path
import secrets
import time
from xml.etree import ElementTree
from zipfile import ZipFile

def lan(address):
    v=ipaddress.ip_address(address)
    if v.version!=4 or not (v.is_private or v.is_loopback):raise ValueError("private IPv4 required")
    return str(v)

def serve(zip_path,package_receipt,repo_receipt,bind,allow,advertise,port,seconds):
    bind,allow,advertise=map(lan,(bind,allow,advertise))
    if not 60<=seconds<=1800 or not 1<=port<=65535:raise ValueError("invalid server lifetime/port")
    proof=json.loads(package_receipt.read_text(encoding="utf8"))
    payload=zip_path.read_bytes()
    if hashlib.sha256(payload).hexdigest()!=proof["sha256"]:raise ValueError("private package mismatch")
    with ZipFile(zip_path) as z:
        meta=ElementTree.fromstring(z.read("install.xml"))
        if meta.findtext("module")!="Plugins::DarcPrePlayer::Plugin" or meta.findtext("version")!="0.3":
            raise ValueError("unexpected package")
    prefix="/"+secrets.token_hex(16)+"/"
    root=f"http://{advertise}:{port}"+prefix
    index=(f'<?xml version="1.0"?><extensions><plugins><plugin name="DarcPrePlayer" version="0.3" '
           f'minTarget="9.0" maxTarget="9.*" category="tools" creator="Daphile audio bench" '
           f'url="{root}DarcPrePlayer.zip" sha="{hashlib.sha1(payload).hexdigest()}">'
           '<title lang="EN">Bounded PCM diagnostic</title><desc lang="EN">Owner-configured trial</desc>'
           '</plugin></plugins><details><title lang="EN">Private temporary trial</title></details></extensions>').encode()
    routes={prefix+"index.xml":index,prefix+"DarcPrePlayer.zip":payload}
    class Handler(BaseHTTPRequestHandler):
        def log_message(self,*_):pass
        def response(self,send):
            if self.client_address[0] not in (allow,"127.0.0.1") or self.path not in routes:
                self.send_error(404);return
            raw=routes[self.path]
            self.send_response(200);self.send_header("Content-Length",str(len(raw)))
            self.send_header("Cache-Control","no-store");self.end_headers()
            if send:self.wfile.write(raw)
        def do_GET(self):self.response(True)
        def do_HEAD(self):self.response(False)
    with HTTPServer((bind,port),Handler) as server:
        server.timeout=1
        with repo_receipt.open("x",encoding="utf8") as f:
            json.dump({"name":"DarcPrePlayer","repo":root+"index.xml","sha256":proof["sha256"],
                       "bind":bind,"allow":allow,"ttl_seconds":seconds},f,indent=2);f.write("\n")
        print("PRIVATE_REPOSITORY_READY",flush=True)
        end=time.monotonic()+seconds
        while time.monotonic()<end:server.handle_request()
    print("PRIVATE_REPOSITORY_STOPPED",flush=True)

if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("private_zip",type=Path);p.add_argument("private_package_receipt",type=Path)
    p.add_argument("private_repo_receipt",type=Path)
    p.add_argument("--bind",required=True);p.add_argument("--allow",required=True)
    p.add_argument("--advertise",required=True);p.add_argument("--port",required=True,type=int)
    p.add_argument("--seconds",type=int,default=720)
    a=p.parse_args();serve(a.private_zip,a.private_package_receipt,a.private_repo_receipt,
                           a.bind,a.allow,a.advertise,a.port,a.seconds)
