# Prova PCM personale separata dalla ISO .75

La ISO generica di base è la .75 verificata, SHA-256
`76081f0321226e3dac8a8d6fd7f821a340a640c7e35ff2a24497f12742c5abd8`.
Il modulo audio contenuto rimane 0.4.74. Non è stata ancora prodotta una
nuova ISO con il pilota .03; nessun pacchetto personale è destinato alla ISO.

Il percorso preparato tiene separati:

* la ISO generica, priva di musica, profili, MAC del proprietario e chiavi;
* un pacchetto LMS privato .03, generato per i file e il player scelti;
* una ricevuta privata con chiave temporanea e profilo per il comando di prova.

La versione .03 è diagnostica: non ha una schermata propria per scegliere
file e preset. La configurazione avviene dal computer del proprietario; il
gestore plugin LMS usa il consueto repository temporaneo e le azioni
diagnostiche usano solo i comandi LMS dedicati protetti dalla chiave generata.
Non è un'interfaccia generica per eseguire comandi sul dispositivo.

## Preparazione personale dopo il boot

1. Caricare o rendere disponibili i propri FLAC nella libreria live, attendere
   la scansione e raccogliere gli URL `file:///srv/mediaserver/music/...`
   restituiti da LMS. Il contenuto dei file scelti sul computer di preparazione
   deve coincidere con quello accessibile alla live. I file su RAM Drive sono
   volatili e dopo un reboot dell'intera live vanno caricati nuovamente.
2. Conoscere il MAC del player LMS scelto e salvare privatamente il profilo
   selezionato tramite l'API ufficiale del modulo Camilla. Il programma
   richiede l'oggetto `profile`, non la risposta intera dell'API.
3. Creare un JSON **privato** con la forma:

   ```json
   {
     "player_mac": "<MAC_PLAYER>",
     "profile": "<OGGETTO_PROFILO_CAMILLA>",
     "sources": [
       {
         "local_path": "<PERCORSO_LOCALE_FLAC>",
         "target_url": "file:///srv/mediaserver/music/<PERCORSO_FLAC>"
       }
     ]
   }
   ```

   `profile` nello schema illustrato è un segnaposto: va sostituito con
   l'oggetto JSON completo, non con una stringa.
4. Sul computer che possiede il workspace e i file, eseguire:

   ```text
   python -B next_audio_20261127/iso_preplayer_generic/build_personal_03.py INPUT_PRIVATO.json PACCHETTO_PRIVATO.zip RICEVUTA_PRIVATA.json
   ```

   Calcola SHA e formato dei file, valida il profilo e genera una nuova chiave.
   ZIP, input e ricevuta contengono informazioni personali: non distribuirli
   nella ISO o in un repository pubblico. Conservare la ricevuta per il
   controllo del pilota e per verificare lo SHA del pacchetto.
5. Servire temporaneamente ZIP e indice soltanto sulla rete amministrativa
   fidata con `serve_personal_repo.py`, specificando esplicitamente indirizzo
   locale, indirizzo LMS ammesso, indirizzo pubblicizzato, porta e durata.
   L'URL del repository è scritto nella ricevuta privata del server. Il
   trasporto HTTP non è cifrato; scegliere una rete fidata. Il server non
   configura il firewall e serve soltanto indice e ZIP con percorso casuale.
6. Aggiungere quell'URL nel normale gestore plugin LMS, abilitare il plugin e
   seguire il suo link di riavvio **del solo LMS**. Non riavviare l'intera
   live fra i lati di una prova, perché i dati temporanei andrebbero persi.
7. Con `control_personal.py`, usare soltanto `prepare`, `arm`, `status`
   e `disarm` contro l'origine HTTP LMS privata e la ricevuta privata. Prima
   di armare assicurarsi che il percorso DSP ordinario sia in bypass, per non
   applicare due volte il preset. La funzione `prepare` richiede player
   connesso, preflight riuscito e motore registrato. A prova conclusa fermare
   la riproduzione e disarmare: il plugin rifiuta il disarmo con pipeline attiva.

Il pilota accetta 1–10 FLAC PCM stereo da 16 o 24 bit e al massimo 256 MiB per
file, alle frequenze previste dalla .03. Il controllo del formato DoP usa il
gate della .03; i DSF restano sul percorso nativo. Sono richiesti lettura
stabile e lease sul filesystem: il preflight può rifiutare una condivisione
di rete che non li supporta. Seek, gapless e altre sorgenti non sono qualificati.

## Evidenze e limiti

Il generatore personale ha superato due fixture sintetiche: controlli su
configurazione e sorgenti, chiavi distinte, confronto byte per byte del codice
del plugin esclusa la configurazione personale, e rifiuto di percorsi errati.
Il test è `test_personal_03.py`; non ha toccato il t630.

La VM KVM sulla ISO .75 ha avviato la live in RAM e caricato/riletto un FLAC
sintetico. Il form LMS ha offerto il plugin dopo l'aggiunta del repository ed
è stata inviata la richiesta di abilitarlo; al controllo immediato non è
comparso il link nativo di riavvio LMS. La prova si è quindi fermata con
esito **FAIL**: installazione completa, preflight, arm/disarm e reboot
restano da verificare. Non è ancora noto se il link mancasse per un ritardo
o per un altro motivo. La sentinella virtuale e la ISO base sono inalterate.
La ricevuta è `VM_075_PERSONAL_RESULT.json`.

Il pacchetto sintetico ricostruito su Matteo aveva tutti i membri uguali a
quelli generati su WIN; lo ZIP complessivo non era byte per byte identico.
`serve_personal_repo.py` e `control_personal.py` sono strumenti preparati
per questa procedura e richiedono le prove di integrazione corrispondenti.
Le misure fisiche della .03 e l'eventuale rilascio restano decisioni separate.
