"""Call only the bounded .03 diagnostic actions through standard LMS JSON-RPC."""
import argparse
import ipaddress
import json
from pathlib import Path
import time
from urllib.parse import urlsplit
from urllib.request import Request,build_opener,ProxyHandler

def control(endpoint,receipt_path,action):
    u=urlsplit(endpoint)
    if u.scheme!="http" or not u.hostname or u.username or u.password or u.query or u.fragment or u.path not in ("","/"):
        raise ValueError("expected private LMS HTTP origin")
    ip=ipaddress.ip_address(u.hostname)
    if not (ip.is_private or ip.is_loopback):raise ValueError("private LMS address required")
    receipt=json.loads(receipt_path.read_text(encoding="utf8"))
    key=receipt["api_key"]
    op=build_opener(ProxyHandler({}))
    def rpc(name,arg="-"):
        body=json.dumps({"id":1,"method":"slim.request","params":["",["darcbench",name,key,arg]]}).encode()
        req=Request(endpoint.rstrip("/")+"/jsonrpc.js",data=body,headers={"Content-Type":"application/json"})
        with op.open(req,timeout=15) as r:result=json.load(r)
        if result.get("error"):raise RuntimeError("diagnostic RPC failed")
        return result["result"]
    if action=="prepare":
        current=rpc("status")
        if current.get("state")=="armed":raise RuntimeError("already armed")
        start=rpc("preflight")
        if start.get("state")!="preflight-started":raise RuntimeError("preflight refused")
        end=time.monotonic()+180
        while time.monotonic()<end:
            current=rpc("status")
            if current.get("preflight"):break
            time.sleep(1)
        else:raise RuntimeError("preflight timeout")
        if current["preflight"].get("state")!="ready":raise RuntimeError("preflight refused; inspect private result")
        if not current.get("player_connected"):raise RuntimeError("selected player is not connected")
        if not current.get("engine_bin_registered"):raise RuntimeError("engine not registered")
        return {"state":"ready","player_connected":True,"engine_bin_registered":True}
    if action=="arm":
        current=rpc("status")
        if not current.get("player_connected") or current.get("preflight",{}).get("state")!="ready":
            raise RuntimeError("preflight or player not ready")
        result=rpc("arm",receipt["profile_b64"])
    elif action=="status":result=rpc("status")
    elif action=="disarm":result=rpc("disarm")
    else:raise ValueError("unsupported action")
    return {"state":result.get("state"),"reason":result.get("reason"),
            "player_connected":result.get("player_connected")}

if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("lms_origin");p.add_argument("private_receipt",type=Path)
    p.add_argument("action",choices=["prepare","arm","status","disarm"])
    a=p.parse_args();print(json.dumps(control(a.lms_origin,a.private_receipt,a.action)))
