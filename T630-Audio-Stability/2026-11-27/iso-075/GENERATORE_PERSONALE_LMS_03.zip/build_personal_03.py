"""Build a private, owner-specific .03 LMS package from explicit local inputs.

The generic .75 ISO remains unchanged. Never place this output, input document,
or receipt in a public image or repository. This program does not access LMS.
"""
import argparse
import base64
import hashlib
import importlib.util
import json
import os
from pathlib import Path, PurePosixPath
import re
import secrets
from urllib.parse import unquote, urlsplit
from zipfile import ZipFile

ROOT=Path(__file__).resolve().parents[2]
ORIGINAL=ROOT/"next_audio_20261127/lms_preplayer_lab/library_v03/build_bundle.py"
MODEL=ROOT/"next_audio_20261127/lms_preplayer_lab/streaming/peq/model.py"
MODEL_SHA="eb6162816a40d47eca9011d65f86b3dc3f7d9ab6898b5bcd3633390a78a2ccb7"
RATES={44100,48000,88200,96000,176400,192000,352800,384000}
MAX_INPUT=256*1024*1024

def module(path,name):
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    return mod

def flac_source(path):
    with path.open("rb") as f:
        before=os.fstat(f.fileno());head=f.read(42)
        if len(head)!=42 or head[:4]!=b"fLaC" or head[4]&127 or head[5:8]!=b"\0\0\x22":
            raise ValueError("expected FLAC STREAMINFO")
        n=int.from_bytes(head[18:26],"big")
        rate=n>>44;channels=((n>>41)&7)+1;bits=((n>>36)&31)+1;samples=n&((1<<36)-1)
        if rate not in RATES or channels!=2 or bits not in (16,24) or not samples or before.st_size>MAX_INPUT:
            raise ValueError("source outside .03 PCM limits")
        f.seek(0);digest=hashlib.file_digest(f,"sha256").hexdigest()
        after=os.fstat(f.fileno())
        if (before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns,before.st_ctime_ns)!=(
            after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns):
            raise ValueError("source changed during read")
    return {"sha256":digest,"rate":rate,"bits":bits,"bytes":before.st_size}

def target_path(url):
    u=urlsplit(url)
    if u.scheme!="file" or u.netloc or u.query or u.fragment:
        raise ValueError("select an LMS local file URL")
    path=unquote(u.path,errors="strict")
    parts=PurePosixPath(path).parts
    if (not path.startswith("/srv/mediaserver/music/") or not path.lower().endswith(".flac") or
        any(p in (".","..") for p in parts) or not all(ch.isalnum() or ch in " /_.-'()[]," for ch in path)):
        raise ValueError("unsafe or unsupported source path")
    return path

def build(input_path,zip_path,receipt_path):
    if zip_path.exists() or receipt_path.exists():raise FileExistsError("choose new private output paths")
    request=json.loads(input_path.read_text(encoding="utf8"))
    if not isinstance(request,dict) or set(request)!={"player_mac","profile","sources"}:
        raise ValueError("expected player_mac, profile and sources")
    mac=request["player_mac"].lower() if isinstance(request["player_mac"],str) else ""
    if not re.fullmatch(r"(?:[0-9a-f]{2}:){5}[0-9a-f]{2}",mac) or int(mac[:2],16)&1:
        raise ValueError("a unicast player MAC is required")
    entries=request["sources"]
    if not isinstance(entries,list) or not 1<=len(entries)<=10:raise ValueError("choose 1 to 10 FLAC files")
    if hashlib.sha256(MODEL.read_bytes()).hexdigest()!=MODEL_SHA:raise ValueError("unexpected profile model")
    model=module(MODEL,"darc_checked_model")
    rows=[];details=[];seen=set()
    for i,item in enumerate(entries,1):
        if not isinstance(item,dict) or set(item)!={"local_path","target_url"}:
            raise ValueError("each source needs local_path and target_url")
        dest=target_path(item["target_url"])
        if dest in seen:raise ValueError("duplicate target")
        seen.add(dest);source=flac_source(Path(item["local_path"]))
        profile=model.validate(request["profile"],source["rate"])
        if not profile["enabled"] or profile["bypass"]:raise ValueError("active PCM profile required")
        role=f"track{i:02}"
        rows.append({"role":role,"path":dest,"sha256":source["sha256"],"rate":source["rate"],"bits":source["bits"]})
        details.append({"role":role,"target_url":item["target_url"],**source})
    raw=json.dumps(request["profile"],sort_keys=True,separators=(",",":"),ensure_ascii=True,allow_nan=False).encode()
    if len(raw)>65536:raise ValueError("profile too large")
    original=module(ORIGINAL,"darc_03_builder")
    key=secrets.token_hex(24)
    cfg={"mac":mac,"api_key":key,"profile_sha256":hashlib.sha256(raw).hexdigest(),
         "engine_sha256":original.ENGINE_SHA,"ffmpeg":"/usr/bin/ffmpeg","ffmpeg_sha256":original.FFMPEG_SHA,
         "sources":rows,"engines":[{"package_relative":"Bin/x86_64-linux/darc-camilladsp"}]}
    payload=original.make_zip(cfg)
    with zip_path.open("xb") as f:f.write(payload)
    result={"sha256":hashlib.sha256(payload).hexdigest(),"api_key":key,"profile_b64":base64.b64encode(raw).decode(),
            "profile_sha256":cfg["profile_sha256"],"sources":details,"status":"PERSONAL_PACKAGE_NOT_INSTALLED"}
    try:
        with receipt_path.open("x",encoding="utf8") as f:json.dump(result,f,indent=2);f.write("\n")
    except BaseException:
        zip_path.unlink()
        raise
    with ZipFile(zip_path) as z:
        if json.loads(z.read("config.json"))!=cfg or z.testzip() is not None:raise RuntimeError("package reread failed")
    return {"status":result["status"],"sha256":result["sha256"],"source_count":len(rows)}

if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("private_input",type=Path);p.add_argument("private_zip",type=Path);p.add_argument("private_receipt",type=Path)
    a=p.parse_args();print(json.dumps(build(a.private_input,a.private_zip,a.private_receipt)))
