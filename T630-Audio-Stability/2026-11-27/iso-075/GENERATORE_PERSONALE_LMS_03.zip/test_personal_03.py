import importlib.util
import json
from pathlib import Path
import subprocess
import tempfile
import unittest
from zipfile import ZipFile

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location("builder",HERE/"build_personal_03.py")
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)

class Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp=tempfile.TemporaryDirectory(prefix="synthetic-",dir=HERE)
        cls.root=Path(cls.tmp.name)
        cls.audio=cls.root/"synthetic.flac"
        subprocess.run(["ffmpeg","-nostdin","-v","error","-f","lavfi","-i","sine=frequency=1000:sample_rate=44100",
                        "-t","0.3","-ac","2","-c:a","flac","-sample_fmt","s16",str(cls.audio)],
                       check=True,timeout=20)
        model=b.module(b.MODEL,"test_model")
        profile=model.flat();profile["enabled"]=True
        profile["peq"]["L"]=[model.new_band("Peaking",1000,3,1)]
        profile["peq"]["R"]=[model.new_band("Peaking",1000,3,1)]
        cls.req={"player_mac":"02:00:00:00:00:01","profile":profile,
                 "sources":[{"local_path":str(cls.audio),
                    "target_url":"file:///srv/mediaserver/music/RAM%20Drive/Trial/Synthetic.flac"}]}
    @classmethod
    def tearDownClass(cls):cls.tmp.cleanup()

    def package(self,name,req):
        p=self.root/(name+".json");z=self.root/(name+".zip");r=self.root/(name+".private.json")
        p.write_text(json.dumps(req),encoding="utf8")
        result=b.build(p,z,r)
        return result,z,json.loads(r.read_text(encoding="utf8"))

    def test_owner_identity_random_key_and_immutable_plugin(self):
        r1,z1,secret1=self.package("a",self.req)
        req2=json.loads(json.dumps(self.req));req2["player_mac"]="02:00:00:00:00:02"
        r2,z2,secret2=self.package("b",req2)
        self.assertNotEqual(secret1["api_key"],secret2["api_key"])
        with ZipFile(z1) as a,ZipFile(z2) as c:
            self.assertEqual(set(a.namelist()),set(c.namelist()))
            for n in a.namelist():
                if n!="config.json":self.assertEqual(a.read(n),c.read(n),n)
            cfg=json.loads(a.read("config.json"))
            self.assertEqual(cfg["mac"],self.req["player_mac"])
            self.assertEqual(cfg["sources"][0]["rate"],44100)
            self.assertEqual(cfg["sources"][0]["bits"],16)
            self.assertNotIn(str(self.audio).encode(),a.read("config.json"))
            self.assertEqual((a.getinfo("config.json").external_attr>>16)&0o777,0o600)
        self.assertEqual(r1["source_count"],1)

    def test_missing_and_unsafe_sources_refused(self):
        for path in ("file:///etc/passwd", "http://host/x.flac",
                     "file:///srv/mediaserver/music/../../etc/file.flac",
                     "file:///srv/mediaserver/music/a%3Bcmd.flac"):
            with self.assertRaises(ValueError):b.target_path(path)
        bad=json.loads(json.dumps(self.req));bad["profile"]["enabled"]=False
        with self.assertRaises(ValueError):self.package("disabled",bad)

if __name__=="__main__":unittest.main()
