"""Boot a disposable overlay of the installed synthetic USB using SeaBIOS."""
from http.cookiejar import CookieJar
import importlib.util
import json
import os
from pathlib import Path
import socket
import subprocess
import tempfile
import time
import urllib.request

import probe_gui_075 as p

SRC=p.OUT/'boot-usb-overlay.qcow2'
OUT=Path('/mnt/c/Build/Daphile-Kernel/iso_candidate_075_live_install/bios-installed')
helper_path=Path('/mnt/c/Build/Daphile-Kernel/iso_candidate_074_dsd_default/kvm_074.py')
spec=importlib.util.spec_from_file_location('kvm_helper',helper_path);helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)


def main():
    if os.geteuid()!=0 or not Path('/dev/kvm').exists():raise RuntimeError('KVM unavailable')
    primary=json.loads((p.OUT/'RESULT.json').read_text())
    if not primary.get('sentinel_unchanged') or not primary.get('base_unchanged'):
        raise RuntimeError('original installed VM is not safely stopped')
    source_sha=p.sha(SRC);OUT.mkdir(parents=True,exist_ok=False)
    image=OUT/'bios-usb-overlay.qcow2'
    p.run('qemu-img','create','-f','qcow2','-F','qcow2','-b',SRC,image)
    backing=json.loads(p.run('qemu-img','info','--output=json',image))
    if Path(backing['full-backing-filename']).resolve()!=SRC.resolve():raise RuntimeError('wrong backing')
    internal=OUT/'internal.raw';payload=OUT/'sentinel.txt';payload.write_text('BIOS SYNTHETIC SENTINEL\n')
    with internal.open('xb') as f:f.truncate(96*1024*1024)
    p.run('mkfs.ext4','-q','-F','-L','BIOS_SENTINEL',internal)
    p.run('debugfs','-w','-R','write '+str(payload)+' /SENTINEL.txt',internal)
    sentinel_sha=p.sha(internal)
    ports=[]
    for _ in range(2):
        with socket.socket() as s:s.bind(('127.0.0.1',0));ports.append(s.getsockname()[1])
    if ports[0]==ports[1]:raise RuntimeError('ports overlap')
    http,lms=ports;control=Path(tempfile.mkdtemp(prefix='bios-usb-qmp-'))/'monitor.sock'
    argv=['qemu-system-x86_64','-name','daphile-installed-bios-synthetic',
          '-machine','q35,accel=kvm','-cpu','host','-m','3072','-smp','4','-display','none',
          '-monitor','none','-serial','file:'+str(OUT/'serial.log'),'-qmp','unix:'+str(control)+',server=on,wait=off',
          '-nic',f'user,restrict=on,model=e1000,hostfwd=tcp:127.0.0.1:{http}-:80,hostfwd=tcp:127.0.0.1:{lms}-:9000',
          '-drive',f'file={internal},format=raw,if=virtio','-device','qemu-xhci,id=usbcontroller',
          '-drive',f'file={image},format=qcow2,if=none,id=bootusb',
          '-device','usb-storage,bus=usbcontroller.0,drive=bootusb,serial=DAPHILE_BIOS_TEST,removable=on,bootindex=1',
          '-boot','strict=on']
    result={'status':'RUNNING','scope':'SeaBIOS/KVM on copy-on-write synthetic USB; no physical disks or audio',
            'installed_source_sha256_before':source_sha,'sentinel_sha256_before':sentinel_sha,'observations':[]}
    receipt=OUT/'RESULT.json'
    def save():receipt.write_text(json.dumps(result,indent=2)+'\n')
    opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),urllib.request.HTTPCookieProcessor(CookieJar()))
    with (OUT/'qemu.log').open('xb') as log:proc=subprocess.Popen(argv,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT)
    start=time.monotonic();last=None
    try:
        while time.monotonic()-start<360:
            if proc.poll() is not None:raise RuntimeError('BIOS VM exited early')
            status=helper.read_status(opener,http,lms);status['elapsed_seconds']=round(time.monotonic()-start,1)
            key=tuple(status[k] for k in ('http','lms','catalog','camilla','rme'))
            if key!=last:result['observations'].append(status);save();print(json.dumps(status),flush=True);last=key
            if key==(200,'9.0.3','0.4.74','0.4.74','READY'):break
            time.sleep(5)
        else:raise RuntimeError('BIOS services not ready')
        def get(name):
            with opener.open(f'http://127.0.0.1:{http}/cgi-bin/'+name,timeout=12) as r:return r.read()
        build=json.loads(get('daphile.json'));sysinfo=get('sysinfo.cgi').decode('utf8','replace')
        (OUT/'sysinfo.html').write_text(sysinfo,encoding='utf8')
        section=sysinfo.split('Filesystem mounts:',1)[1].split('Kernel modules:',1)[0]
        mounts=[x.strip() for x in section.splitlines() if ' on ' in x and ' type ' in x]
        if build.get('build')!='fw2611270750':raise RuntimeError('wrong BIOS boot firmware')
        if not any(x.startswith('/dev/sda2 on /boot type ext4 ') for x in mounts):raise RuntimeError('boot on wrong target')
        if not any(x.startswith('/dev/sda3 on /mnt/hdd type ext4 ') for x in mounts):raise RuntimeError('DATA on wrong target')
        if any(x.startswith('/dev/vda') for x in mounts):raise RuntimeError('internal sentinel mounted')
        result.update(application_status='APP_PASS',firmware=build['build'],mounts=mounts)
    except Exception as exc:result.update(application_status='APP_FAILED',error=repr(exc))
    finally:
        if proc.poll() is None:
            try:p.qmp(control,'quit')
            except Exception:proc.terminate()
            try:proc.wait(timeout=10)
            except subprocess.TimeoutExpired:proc.kill();proc.wait()
        result['sentinel_sha256_after']=p.sha(internal);result['installed_source_sha256_after']=p.sha(SRC)
        result['status']='PASS' if result.get('application_status')=='APP_PASS' and result['sentinel_sha256_after']==sentinel_sha and result['installed_source_sha256_after']==source_sha else 'NOT_QUALIFIED'
        save();print(json.dumps({'status':result['status'],'receipt':str(receipt)}),flush=True)


if __name__=='__main__':main()
