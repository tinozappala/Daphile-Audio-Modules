"""Read only standard GUI endpoints of the still-running installed VM."""
from http.cookiejar import CookieJar
import hashlib
import json
from pathlib import Path
import re
import urllib.request
import xml.etree.ElementTree as ET

OUT=Path('/mnt/c/Build/Daphile-Kernel/live_usb_install_vm_075')
state=json.loads((OUT/'RESULT.json').read_text())
install=json.loads((OUT/'INSTALL_RESULT.json').read_text())
if state['status']!='UI_CAPTURED_WAITING_FOR_LOCAL_DECISION' or not install['second_boot_http_returned']:
    raise RuntimeError('installed VM is not running at expected stage')
url=f"http://127.0.0.1:{state['http_port']}/cgi-bin/"
opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),urllib.request.HTTPCookieProcessor(CookieJar()))
def get(name):
    with opener.open(url+name,timeout=20) as r:return r.read()

build=json.loads(get('daphile.json'))
if build.get('build')!='fw2611270750':raise RuntimeError('wrong installed firmware')
catalog=ET.fromstring(get('AudioPlugins/extensions.xml'))
plugin=catalog.find("./plugins/plugin[@name='DaphileCamillaDSP']")
if plugin is None or plugin.get('version')!='0.4.74':raise RuntimeError('wrong installed catalog version')
archive=get('AudioPlugins/DaphileCamillaDSP-0.4.74.zip')
archive_sha=hashlib.sha256(archive).hexdigest()
if archive_sha!='c2ef7df33a91df6b5888e13e150c784946f43e575876c922346e806c848fe508':
    raise RuntimeError('installed archive differs from .74')
session=json.loads(get('CamillaPlugin/api/session'))
if not session.get('authenticated'):raise RuntimeError('Camilla session unavailable')
camilla=json.loads(get('CamillaPlugin/api/status'))
if camilla.get('module_version')!='0.4.74':raise RuntimeError('wrong running module')
log=get('logread.cgi').decode('utf8','replace')
(OUT/'installed-log.html').write_text(log,encoding='utf8')
match=re.search(r'Kernel command line: ([^\r\n<]+)',log)
if not match:raise RuntimeError('installed boot command line not available')
cmdline=match.group(1).split()
system=get('sysinfo.cgi').decode('utf8','replace')
(OUT/'installed-sysinfo.html').write_text(system,encoding='utf8')
mount_section=system.split('Filesystem mounts:',1)[1].split('Kernel modules:',1)[0]
mount_lines=[x.strip() for x in mount_section.splitlines() if ' on ' in x and ' type ' in x]
if not any(x.startswith('/dev/sda2 on /boot type ext4 ') for x in mount_lines):raise RuntimeError('boot is not on target')
if not any(x.startswith('/dev/sda3 on /mnt/hdd type ext4 ') for x in mount_lines):raise RuntimeError('data is not on target')
if any(re.match(r'^/dev/vda',x) for x in mount_lines):raise RuntimeError('internal sentinel was mounted')
report={'status':'PASS','scope':'official read-only GUI endpoints on disposable VM',
        'firmware':build['build'],'catalog_module_version':plugin.get('version'),
        'running_module_version':camilla['module_version'],'archive_sha256':archive_sha,
        'kernel_log_command_line_excerpt':match.group(1),
        'marker_visible_in_log_excerpt':'daphile_installed=1' in cmdline,
        'log_command_line_may_be_truncated':True,'target_boot_and_data_ext4':True,
        'internal_sentinel_unmounted':True,'mount_lines':mount_lines}
with (OUT/'INSTALLED_GUI_VERIFICATION.json').open('x') as f:json.dump(report,f,indent=2);f.write('\n')
print(json.dumps(report,indent=2),flush=True)
