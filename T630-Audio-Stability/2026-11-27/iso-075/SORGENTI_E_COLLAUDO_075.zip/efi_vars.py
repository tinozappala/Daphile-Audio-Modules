"""Read active boot variables from an authenticated EDK2 OVMF varstore copy.

Read-only; this recognizes the authenticated header used by OVMF_VARS_4M.
Ambiguous active entries are rejected rather than guessed.
"""
import hashlib
import re
import struct

GLOBAL_GUID=bytes.fromhex('61dfe48bca93d211aa0d00e098032b8c')


def bootvars(data):
    records={}
    for match in re.finditer(b'\xaa\x55',data):
        pos=match.start()
        if pos+60>len(data) or data[pos+2]!=0x3f or data[pos+3]!=0:continue
        if data[pos+44:pos+60]!=GLOBAL_GUID:continue
        namesize,databytes=struct.unpack_from('<II',data,pos+36)
        if namesize<2 or namesize>512 or namesize%2 or databytes>65536:continue
        name_start=pos+60;end_name=name_start+namesize;end_data=end_name+databytes
        if end_data>len(data):continue
        try:name=data[name_start:end_name].decode('utf-16-le').rstrip('\x00')
        except UnicodeDecodeError:continue
        if not re.fullmatch(r'Boot(?:Order|Next|[0-9A-Fa-f]{4})',name):continue
        if name in records:raise ValueError('multiple active variable records: '+name)
        value=data[end_name:end_data]
        row={'data_sha256':hashlib.sha256(value).hexdigest(),'size':len(value)}
        if name=='BootOrder':
            if len(value)%2:raise ValueError('odd BootOrder length')
            row['order']=[f'{v:04X}' for (v,) in struct.iter_unpack('<H',value)]
        elif name=='BootNext':
            if len(value)!=2:raise ValueError('invalid BootNext length')
            row['next']=f'{struct.unpack("<H",value)[0]:04X}'
        else:
            if len(value)<8:raise ValueError('invalid load option')
            row['attributes'],row['path_length']=struct.unpack_from('<IH',value)
            chars=[];i=6
            while i+1<len(value):
                pair=value[i:i+2];i+=2
                if pair==b'\x00\x00':break
                chars.append(pair)
            else:raise ValueError('unterminated load option description')
            row['description']=b''.join(chars).decode('utf-16-le','strict')
            if i+row['path_length']>len(value):raise ValueError('invalid load option path')
            row['device_path_sha256']=hashlib.sha256(value[i:i+row['path_length']]).hexdigest()
        records[name]=row
    if 'BootOrder' not in records:raise ValueError('no active BootOrder in recognized varstore')
    return records
