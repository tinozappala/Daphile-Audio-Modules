"""Inspect the stopped synthetic USB as files, without mounting it."""
import hashlib
import json
from pathlib import Path
import re
import subprocess

OUT=Path('/mnt/c/Build/Daphile-Kernel/live_usb_install_vm_075')
IMAGE=OUT/'boot-usb-after.raw';BOOT=OUT/'boot-partition-after.raw'
ROOT_SHA='1fe48c2b563dbfaa8bad90f4c4344eb22ca7e1cba841374edd82c6431386da69'
INITRD_SHA='4fbad37af58794245b4ae8da70caf1e80986596e8467124b00cf9c88d42ee5f4'
state=json.loads((OUT/'RESULT.json').read_text());installed=json.loads((OUT/'INSTALLED_GUI_VERIFICATION.json').read_text())
if not state.get('base_unchanged') or not state.get('sentinel_unchanged') or installed['status']!='PASS':
    raise RuntimeError('VM verification incomplete')


def command(*args):
    p=subprocess.run([str(x) for x in args],capture_output=True,timeout=180)
    return {'args':[str(x) for x in args],'exit':p.returncode,
            'stdout':p.stdout.decode(errors='replace'),'stderr':p.stderr.decode(errors='replace')}


def sha(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()


table_result=command('sfdisk','--json',IMAGE)
if table_result['exit']:raise RuntimeError('partition table unavailable')
table=json.loads(table_result['stdout'])['partitiontable'];parts=table['partitions'];sector=table.get('sectorsize',512)
if table['label']!='dos' or len(parts)!=3 or [x['type'] for x in parts]!=['ef','83','83']:
    raise RuntimeError('unexpected installed partition layout')
offset=parts[1]['start']*sector;size=parts[1]['size']*sector
if size!=1073741824:raise RuntimeError('unexpected boot partition size')
with IMAGE.open('rb') as src,BOOT.open('xb') as dst:
    dst.truncate(size);src.seek(offset);pos=0
    while pos<size:
        chunk=src.read(min(4*1024*1024,size-pos))
        if not chunk:raise RuntimeError('short image')
        if any(chunk):dst.seek(pos);dst.write(chunk)
        pos+=len(chunk)
probe={'partition_table':table,'filesystems':[],'boot_listing':[]}
for part in parts:
    probe['filesystems'].append(command('blkid','-p','-O',str(part['start']*sector),
                                      '-S',str(part['size']*sector),IMAGE))
esp=f'{IMAGE}@@{parts[0]["start"]*sector}'
efi=command('mdir','-i',esp,'::/EFI/boot');probe['efi_fallback_listing']=efi
if efi['exit'] or 'BOOTX64' not in efi['stdout'] or 'BOOTIA32' not in efi['stdout']:
    raise RuntimeError('EFI fallback executables missing')
for request in ('ls -l /','cat /disk.uuid','cat /grub/grub.cfg','stat /EFI/Daphile/bootx64.efi'):
    probe['boot_listing'].append(command('debugfs','-R',request,BOOT))
cfg=probe['boot_listing'][2]['stdout']
if 'daphile_installed=1' not in cfg or 'daphile=fw2611270750' not in cfg:
    raise RuntimeError('installed GRUB marker or firmware mismatch')
if not re.search(r'boot_uuid=[0-9a-f-]{36} data_uuid=[0-9a-f-]{36}',cfg):
    raise RuntimeError('installed GRUB does not bind boot and data UUIDs')
for name,expected in (('rootfs',ROOT_SHA),('initrd',INITRD_SHA)):
    dest=OUT/('installed-'+name)
    result=command('debugfs','-R',f'dump /fw2611270750/{name} {dest}',BOOT)
    if not dest.is_file() or sha(dest)!=expected:raise RuntimeError(name+' installed bytes differ')
    probe[name+'_sha256']=expected
probe.update(status='PASS',installed_grub_marker=True,installed_uuid_binding=True,
             efi_x64_and_ia32_fallback=True)
with (OUT/'DISK_INSPECTION.json').open('x') as f:json.dump(probe,f,indent=2);f.write('\n')
print(json.dumps(probe,indent=2),flush=True)
