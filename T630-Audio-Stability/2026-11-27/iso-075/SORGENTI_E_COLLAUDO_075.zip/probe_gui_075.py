"""Start one disposable KVM VM and inspect the official New Installation UI.

No physical disk or host USB device is passed to QEMU. The live ISO is a
read-only backing file; a uniquely named 4 GiB overlay emulates the boot USB.
This first stage only observes. If the UI permits the live USB, it waits for
an explicit local continuation file in the private test directory.
"""
import hashlib
from html.parser import HTMLParser
from http.cookiejar import CookieJar
import json
import os
from pathlib import Path
import shutil
import socket
import subprocess
import tempfile
import time
import urllib.error
import urllib.request

BASE=Path('/mnt/c/Build/Daphile-Kernel/iso_candidate_075_live_install/Daphile-0.4.75-live-install-candidate.iso')
BASE_SHA='76081f0321226e3dac8a8d6fd7f821a340a640c7e35ff2a24497f12742c5abd8'
OUT=Path('/mnt/c/Build/Daphile-Kernel/live_usb_install_vm_075')


def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()


def run(*args):
    r=subprocess.run([str(a) for a in args],capture_output=True,timeout=90)
    if r.returncode:raise RuntimeError(str(args[0])+': '+r.stderr.decode(errors='replace')[-500:])
    return r.stdout


def qmp(path,action,args=None):
    with socket.socket(socket.AF_UNIX,socket.SOCK_STREAM) as sock:
        sock.settimeout(5);sock.connect(str(path));f=sock.makefile('rwb',buffering=0);json.loads(f.readline())
        def call(action,args=None):
            cmd={'execute':action}
            if args is not None:cmd['arguments']=args
            f.write(json.dumps(cmd).encode()+b'\n')
            while True:
                result=json.loads(f.readline())
                if 'error' in result:raise RuntimeError(str(result['error']))
                if 'return' in result:return result['return']
        call('qmp_capabilities');return call(action,args)


class InstallSelect(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True);self.active=False;self.current=None;self.options=[]
    def handle_starttag(self,tag,attrs):
        attrs=dict(attrs)
        if tag=='select' and attrs.get('id')=='install_drive':self.active=True
        if self.active and tag=='option':self.current={'attributes':attrs,'label':''}
    def handle_data(self,data):
        if self.current is not None:self.current['label']+=data
    def handle_endtag(self,tag):
        if tag=='option' and self.current is not None:
            self.current['label']=self.current['label'].strip();self.options.append(self.current);self.current=None
        if tag=='select':self.active=False


def main():
    if os.geteuid()!=0 or not Path('/dev/kvm').exists():raise RuntimeError('KVM unavailable')
    if sha(BASE)!=BASE_SHA:raise RuntimeError('unexpected immutable ISO')
    OUT.mkdir(parents=True,exist_ok=False)
    sentinel=OUT/'internal-sentinel.raw';text=OUT/'sentinel.txt';text.write_text('SYNTHETIC INTERNAL SENTINEL\n')
    with sentinel.open('xb') as f:f.truncate(96*1024*1024)
    run('mkfs.ext4','-q','-F','-L','DAPHILE_SYNTH',sentinel)
    run('debugfs','-w','-R','write '+str(text)+' /SENTINEL.txt',sentinel)
    before=sha(sentinel)
    overlay=OUT/'boot-usb-overlay.qcow2'
    run('qemu-img','create','-f','qcow2','-F','raw','-b',BASE,overlay,'4G')
    info=json.loads(run('qemu-img','info','--output=json',overlay))
    if info.get('virtual-size')!=4*1024**3 or Path(info.get('full-backing-filename','')).resolve()!=BASE.resolve():
        raise RuntimeError('unexpected overlay backing or size')
    code=Path('/usr/share/OVMF/OVMF_CODE_4M.fd');vsrc=Path('/usr/share/OVMF/OVMF_VARS_4M.fd');vars=OUT/'vars.fd'
    if not code.is_file() or not vsrc.is_file():raise RuntimeError('OVMF unavailable')
    shutil.copyfile(vsrc,vars)
    with socket.socket() as s:s.bind(('127.0.0.1',0));port=s.getsockname()[1]
    qmpdir=Path(tempfile.mkdtemp(prefix='daphile-usb-qmp-'));control=qmpdir/'monitor.sock'
    argv=['qemu-system-x86_64','-name','daphile-install-disposable-075',
      '-machine','q35,accel=kvm','-cpu','host','-m','3072','-smp','4','-display','none',
      '-monitor','none','-serial','file:'+str(OUT/'serial.log'),'-qmp','unix:'+str(control)+',server=on,wait=off',
      '-nic',f'user,restrict=on,model=e1000,hostfwd=tcp:127.0.0.1:{port}-:80',
      '-drive',f'file={sentinel},format=raw,if=virtio',
      '-device','qemu-xhci,id=usbcontroller',
      '-drive',f'file={overlay},format=qcow2,if=none,id=bootusb',
      '-device','usb-storage,bus=usbcontroller.0,drive=bootusb,serial=DAPHILE_VM_BOOT,removable=on,bootindex=1',
      '-boot','strict=on','-drive',f'if=pflash,unit=0,format=raw,readonly=on,file={code}',
      '-drive',f'if=pflash,unit=1,format=raw,file={vars}']
    result={'status':'STARTING','scope':'KVM, restricted network, no physical disks or audio',
            'base_sha256_before':BASE_SHA,'sentinel_sha256_before':before,'overlay':info,
            'http_port':port,'qmp_socket':str(control),'qemu_argv':argv}
    receipt=OUT/'RESULT.json'
    def save():receipt.write_text(json.dumps(result,indent=2)+'\n')
    save();opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),urllib.request.HTTPCookieProcessor(CookieJar()))
    process=None
    try:
        with (OUT/'qemu.log').open('xb') as log:
            process=subprocess.Popen(argv,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT)
            result['pid']=process.pid;save();start=time.monotonic();sent=False;html=None
            while time.monotonic()-start<360:
                if process.poll() is not None:raise RuntimeError('QEMU exited before GUI inspection')
                if not sent and time.monotonic()-start>12:
                    try:qmp(control,'human-monitor-command',{'command-line':'sendkey ret'});sent=True
                    except (OSError,RuntimeError):pass
                try:
                    with opener.open(f'http://127.0.0.1:{port}/cgi-bin/Settings',timeout=4) as r:
                        candidate=r.read().decode('utf8','replace')
                    if 'New Installation' in candidate and 'install_drive' in candidate:html=candidate;break
                except (OSError,urllib.error.URLError):pass
                time.sleep(4)
            if html is None:raise RuntimeError('New Installation UI unavailable within 360 seconds')
            (OUT/'settings-before.html').write_text(html,encoding='utf8')
            try:
                with opener.open(f'http://127.0.0.1:{port}/cgi-bin/sysinfo.cgi',timeout=8) as r:
                    (OUT/'sysinfo-before.html').write_bytes(r.read())
            except Exception as exc:result['sysinfo_error']=repr(exc)
            try:
                with opener.open(f'http://127.0.0.1:{port}/cgi-bin/logread.cgi',timeout=8) as r:
                    logtext=r.read().decode('utf8','replace')
                (OUT/'log-before.html').write_text(logtext,encoding='utf8')
                result['usb_removable_log']=[line.strip() for line in logtext.splitlines()
                    if '[sda]' in line and 'removable disk' in line.lower()]
            except Exception as exc:result['log_error']=repr(exc)
            parsed=InstallSelect();parsed.feed(html);result['install_options']=parsed.options
            result['settings_page_received']=True;result['query_block']=qmp(control,'query-block')
            try:qmp(control,'screendump',{'filename':str(OUT/'screen-before.ppm')})
            except Exception:pass
            result['status']='UI_CAPTURED_WAITING_FOR_LOCAL_DECISION';save()
            print(json.dumps({'status':result['status'],'options':parsed.options,'directory':str(OUT)},indent=2),flush=True)
            deadline=time.monotonic()+900
            while time.monotonic()<deadline and not (OUT/'STOP').exists():
                if process.poll() is not None:break
                time.sleep(2)
            result['status']='VM_STOPPED' if (OUT/'STOP').exists() else 'WAIT_EXPIRED_OR_VM_EXIT'
    except Exception as exc:result['status']='PROBE_FAILED';result['error']=repr(exc)
    finally:
        if process is not None and process.poll() is None:
            try:qmp(control,'quit')
            except Exception:process.terminate()
            try:process.wait(timeout=10)
            except subprocess.TimeoutExpired:process.kill();process.wait()
        result['sentinel_sha256_after']=sha(sentinel)
        result['sentinel_unchanged']=result['sentinel_sha256_after']==before
        result['base_sha256_after']=sha(BASE)
        result['base_unchanged']=result['base_sha256_after']==BASE_SHA
        save();print(json.dumps({'status':result['status'],'sentinel_unchanged':result['sentinel_unchanged'],
                                'base_unchanged':result['base_unchanged']},indent=2),flush=True)


if __name__=='__main__':main()
