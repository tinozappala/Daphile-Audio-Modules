"""Submit the observed official Daphile install form to the disposable VM.

Only the single QEMU boot USB overlay is a valid target. UEFI is checked;
the request and the official status responses are archived before proceeding.
No guest shell, direct fwtool command, physical device, or second install
request is used. Reboot, if reached, uses the normal Settings button.
"""
import hashlib
import json
from pathlib import Path
import time
import urllib.parse
import urllib.request

import efi_vars
import probe_gui_075 as p

OUT=p.OUT


def readvars(label):
    path=OUT/'vars.fd'
    for _ in range(20):
        first=path.read_bytes();time.sleep(.25);second=path.read_bytes()
        if first==second:
            parsed=efi_vars.bootvars(first)
            (OUT/('vars-'+label+'.fd')).write_bytes(first)
            return {'sha256':hashlib.sha256(first).hexdigest(),'boot':parsed}
    raise RuntimeError('firmware vars did not reach a stable read')


def main():
    source=json.loads((OUT/'RESULT.json').read_text())
    if source['status']!='UI_CAPTURED_WAITING_FOR_LOCAL_DECISION':raise RuntimeError('VM is not at expected gate')
    port=source['http_port'];control=Path(source['qmp_socket'])
    block=p.qmp(control,'query-block')
    active={x['device']:x['inserted']['file'] for x in block if x.get('inserted')}
    expected={'virtio0':str(OUT/'internal-sentinel.raw'),'bootusb':str(OUT/'boot-usb-overlay.qcow2'),
              'pflash0':'/usr/share/OVMF/OVMF_CODE_4M.fd','pflash1':str(OUT/'vars.fd')}
    if active!=expected:raise RuntimeError('QEMU devices are not the approved synthetic set')
    if 'DAPHILE_VM_BOOT' not in (OUT/'sysinfo-before.html').read_text():raise RuntimeError('missing USB identity')
    if not source.get('usb_removable_log'):
        raise RuntimeError('official system log does not establish that the target is removable')
    opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
    url=f'http://127.0.0.1:{port}/cgi-bin/'
    def get(name):
        with opener.open(url+name,timeout=10) as response:return response.read()
    html=get('Settings').decode('utf8','replace')
    parser=p.InstallSelect();parser.feed(html)
    target=[o for o in parser.options if o['attributes'].get('value')=='sda']
    internal=[o for o in parser.options if o['attributes'].get('value')=='vda']
    if len(target)!=1 or 'disabled' in target[0]['attributes'] or len(internal)!=1 or 'disabled' not in internal[0]['attributes']:
        raise RuntimeError('official GUI no longer exposes only the expected USB target')
    if target[0]['attributes'].get('data-empty')!='0' or target[0]['attributes'].get('data-msdos')!='true':
        raise RuntimeError('unexpected official GUI partition/default semantics')
    if 'QEMU QEMU HARDDISK' not in target[0]['label'] or '4.2GB' not in target[0]['label']:
        raise RuntimeError('unexpected target label')
    before=readvars('before-install')
    payload={'ACTION':'install','install_drive':'sda','empty_drive':'true','partition_table':'MSDOS','bios_boot':'true','uefi_boot':'true'}
    if payload.get('uefi_boot')!='true':raise RuntimeError('UEFI must be checked')
    record={'status':'READY_TO_POST_ONCE','scope':'official Settings form, synthetic USB only',
            'target':target[0],'internal_option':internal[0],'uefi_checkbox':'checked',
            'post_fields':payload,'before_firmware':before,'progress':[]}
    dest=OUT/'INSTALL_RESULT.json'
    if dest.exists():raise RuntimeError('prior install receipt exists; no second attempt')
    def save():dest.write_text(json.dumps(record,indent=2)+'\n')
    def post(fields):
        body=urllib.parse.urlencode(fields).encode('ascii')
        request=urllib.request.Request(url+'Settings',data=body,headers={'Content-Type':'application/x-www-form-urlencoded'})
        with opener.open(request,timeout=60) as response:return response.read()
    save()
    try:
        record['status']='INSTALL_POST_SENT_ONCE';save()
        response=post(payload);(OUT/'install-response.html').write_bytes(response)
        end=time.monotonic()+300;last=None;final=None
        while time.monotonic()<end:
            try:
                raw=get('ins.json');parsed=json.loads(raw)
                if parsed!=last:
                    record['progress'].append(parsed);save();last=parsed
                    print(json.dumps({'phase':'install','status':parsed.get('status'),'log':parsed.get('log')}),flush=True)
                if parsed.get('status')=='finished':final=parsed;break
            except Exception as exc:
                record['last_poll_error']=repr(exc);save()
            time.sleep(2)
        if final is None:raise RuntimeError('official installation status did not finish; no retry')
        record['final_install_status']=final;record['after_install_firmware']=readvars('after-install')
        record['sentinel_after_install_sha256']=p.sha(OUT/'internal-sentinel.raw')
        save()
        if record['sentinel_after_install_sha256']!=source['sentinel_sha256_before']:
            raise RuntimeError('internal sentinel changed; no reboot requested')
        if record['after_install_firmware']['boot']!=before['boot']:
            raise RuntimeError('firmware boot entries changed; no reboot requested')
        print(json.dumps({'phase':'install_finished','status':final},indent=2),flush=True)
        ack={'ACTION':'ack_install','install_drive':str(final.get('drive') or 'sda')}
        if ack['install_drive']!='sda':raise RuntimeError('unexpected install status drive')
        (OUT/'ack-response.html').write_bytes(post(ack))
        current=get('Settings').decode('utf8','replace')
        (OUT/'settings-after-install.html').write_text(current,encoding='utf8')
        if 'value=reboot' not in current or 'Restart system' not in current:
            raise RuntimeError('normal Restart system button unavailable after installation')
        serial=OUT/'serial.log';initial=serial.read_text(errors='replace').count('BdsDxe: starting')
        record['status']='NORMAL_REBOOT_POST_SENT_ONCE';record['boot_serial_starts_before']=initial;save()
        try:(OUT/'reboot-response.html').write_bytes(post({'ACTION':'reboot'}))
        except Exception as exc:record['reboot_post_result']=repr(exc);save()
        end=time.monotonic()+180;boot_start=False;after_html=None;disconnect=False
        while time.monotonic()<end:
            text=serial.read_text(errors='replace')
            boot_start=text.count('BdsDxe: starting')>initial
            try:
                with opener.open(url+'Settings',timeout=3) as response:page=response.read()
                if boot_start:
                    after_html=page;break
            except Exception:disconnect=True
            time.sleep(3)
        record['second_boot_firmware_entry_seen']=boot_start
        record['http_disconnected_during_reboot']=disconnect
        record['second_boot_http_returned']=after_html is not None
        if after_html is not None:
            (OUT/'settings-second-boot.html').write_bytes(after_html)
            for name in ('sysinfo.cgi','daphile.json','AudioPlugins/extensions.xml'):
                try:
                    raw=get(name)
                    (OUT/('second-'+name.replace('/','_'))).write_bytes(raw)
                    if name=='daphile.json':record['second_boot_daphile']=json.loads(raw)
                    if name=='sysinfo.cgi':
                        text=raw.decode('utf8','replace')
                        record['second_boot_mount_lines']=[line for line in text.splitlines()
                            if ' on /mnt/hdd type ' in line or ' on /boot type ' in line]
                except Exception as exc:record['second_boot_'+name+'_error']=repr(exc)
            save()
        try:
            p.qmp(control,'screendump',{'filename':str(OUT/'screen-after.ppm')})
            record['second_boot_screenshot']='screen-after.ppm'
        except Exception as exc:record['screen_error']=repr(exc)
        record['after_reboot_firmware']=readvars('after-reboot')
        record['status']='OBSERVATION_COMPLETE';save()
        print(json.dumps({'phase':'observation_complete','second_boot':boot_start,
                          'http_returned':after_html is not None},indent=2),flush=True)
    except Exception as exc:
        record['status']='STOPPED_WITH_UNCERTAIN_OR_FAILED_STEP';record['error']=repr(exc);save();raise


if __name__=='__main__':main()
