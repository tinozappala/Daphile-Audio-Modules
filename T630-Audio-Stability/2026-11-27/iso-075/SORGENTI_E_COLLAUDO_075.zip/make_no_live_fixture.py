"""Create a non-distributable .75 VM fixture with only `live` tokens removed.

The candidate ISO remains immutable. The new file differs only in its three
boot option text locations, retaining identical ISO extents and byte length.
"""
import hashlib
import mmap
from pathlib import Path
import shutil

BASE=Path('/mnt/c/Build/Daphile-Kernel/iso_candidate_075_live_install/Daphile-0.4.75-live-install-candidate.iso')
OUT=Path('/mnt/c/Build/Daphile-Kernel/iso_candidate_075_scripts/no-live-test-only.iso')
EXPECTED='76081f0321226e3dac8a8d6fd7f821a340a640c7e35ff2a24497f12742c5abd8'


def sha(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()


if sha(BASE)!=EXPECTED or OUT.exists():raise RuntimeError('unexpected source or pre-existing test fixture')
shutil.copyfile(BASE,OUT)
replacements=[(b'efi=runtime live uefi=64',b'efi=runtime      uefi=64',2),
              (b'efi=runtime live uefi=32',b'efi=runtime      uefi=32',2),
              (b'raid=noautodetect live',b'raid=noautodetect     ',1)]
with OUT.open('r+b') as f,mmap.mmap(f.fileno(),0) as data:
    for old,new,expected in replacements:
        if len(old)!=len(new):raise ValueError('fixture must preserve extents')
        positions=[];start=0
        while True:
            found=data.find(old,start)
            if found<0:break
            positions.append(found);start=found+len(old)
        if len(positions)!=expected:raise ValueError('unexpected boot-option count')
        for pos in positions:data[pos:pos+len(old)]=new
    data.flush()
if sha(BASE)!=EXPECTED:raise RuntimeError('candidate changed')
print('test_only_iso',OUT,'bytes',OUT.stat().st_size,'sha256',sha(OUT),'source_unchanged',True,flush=True)
