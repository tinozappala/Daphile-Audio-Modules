"""Create a test-only ISO with stale sentinel UUIDs and no installed marker."""
import hashlib
import mmap
from pathlib import Path
import shutil

BASE=Path('/mnt/c/Build/Daphile-Kernel/iso_candidate_075_live_install/Daphile-0.4.75-live-install-candidate.iso')
OUT=Path('/mnt/c/Build/Daphile-Kernel/iso_candidate_075_scripts/stale-uuid-test-only.iso')
EXPECTED='76081f0321226e3dac8a8d6fd7f821a340a640c7e35ff2a24497f12742c5abd8'
OLD=b'quiet panic=1 console=tty2 vt.global_cursor_default=0 i915.enable_fbc=0 raid=noautodetect      efi=runtime live uefi=64'
NEW=(b'boot_uuid=11111111-1111-4111-8111-111111111111 '
     b'data_uuid=22222222-2222-4222-8222-222222222222 efi=runtime uefi=64')


def sha(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()


if sha(BASE)!=EXPECTED or OUT.exists() or len(NEW)>len(OLD):raise RuntimeError('unexpected test source')
shutil.copyfile(BASE,OUT)
with OUT.open('r+b') as f,mmap.mmap(f.fileno(),0) as data:
    positions=[];start=0
    while True:
        found=data.find(OLD,start)
        if found<0:break
        positions.append(found);start=found+len(OLD)
    if len(positions)!=2:raise RuntimeError('unexpected 64-bit EFI option count')
    for pos in positions:data[pos:pos+len(OLD)]=NEW+b' '*(len(OLD)-len(NEW))
    data.flush()
if sha(BASE)!=EXPECTED:raise RuntimeError('candidate changed')
print('test_only_iso',OUT,'bytes',OUT.stat().st_size,'sha256',sha(OUT),'source_unchanged',True,flush=True)
