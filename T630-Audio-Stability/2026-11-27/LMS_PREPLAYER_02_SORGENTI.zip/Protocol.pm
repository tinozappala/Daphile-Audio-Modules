package Plugins::DarcPrePlayer::Protocol;
use strict;
use warnings;
use base qw(Slim::Player::Protocols::File);

# Only this diagnostic URL scheme is routed here; ordinary file, FLAC and DSF
# handlers and the player's advertised codecs are untouched.
sub isAudioURL { return 1; }
sub canSeek { return 0; }
sub canDirectStreamSong { return 0; }
sub formatOverride {
    my ($class,$song) = @_;
    return Plugins::DarcPrePlayer::Plugin::permitted($song) ? 'darc' : 'darc-refused';
}
sub getMetadataFor {
    my ($class,$client,$url) = @_;
    return {title => 'Daphile diagnostic stream', type => 'wav'};
}
1;
