#!/usr/bin/env python3
"""Fixed two-URL LMS transcode entry; no user-supplied command or path."""
import fcntl,json,os,sys
from pathlib import Path
from types import SimpleNamespace

def main():
    if len(sys.argv)!=3 or os.geteuid()==0:raise RuntimeError('non-root fixed session required')
    package=Path(__file__).resolve().parent
    session=Path(sys.argv[1])
    st=session.stat()
    if st.st_uid!=os.geteuid() or st.st_mode&0o077:raise RuntimeError('invalid private session')
    cfg=json.loads((package/'config.json').read_bytes())
    url=sys.argv[2]
    roles={f"darcbench://{cfg['url_token']}/{r['role']}.flac":r['path'] for r in cfg['sources']}
    if url not in roles:raise RuntimeError('unrecognized diagnostic URL')
    pre=json.loads((session/'preflight.json').read_bytes())
    if pre.get('state')!='ready':raise RuntimeError('preflight incomplete')
    lockfd=os.open(session/'pipeline.lock',os.O_RDWR|os.O_CREAT|os.O_CLOEXEC,0o600)
    try:
        fcntl.flock(lockfd,fcntl.LOCK_EX|fcntl.LOCK_NB)
        sys.path.insert(0,str(package))
        import stream_filter
        args=SimpleNamespace(input=roles[url],manifest=str(session/'manifest.json'),profile=str(session/'profile.json'),
            engine=pre['engine_path'],ffmpeg=cfg['ffmpeg'],tmpdir=str(session),lab_bridge=cfg.get('fixture_bridge'),lab_debug=False)
        return stream_filter.run(args)
    finally:os.close(lockfd)

if __name__=='__main__':
    try:sys.exit(main())
    except Exception as exc:
        print('DARC_PREPLAYER_REFUSED:'+type(exc).__name__,file=sys.stderr)
        sys.exit(2)
