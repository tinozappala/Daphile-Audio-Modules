import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { once } from 'node:events';
import { access, mkdtemp, readFile, rm } from 'node:fs/promises';
import { createServer } from 'node:http';
import { tmpdir } from 'node:os';
import { isAbsolute, join, relative } from 'node:path';
import { fileURLToPath } from 'node:url';

const ui = process.argv[2] || fileURLToPath(new URL('./DaphileRME/backend/rme/ui/', import.meta.url));
const baseUi = process.argv[3] || fileURLToPath(new URL('../resume_20261027/SOFTWARE_FINISH_20261112/POSTREBOOT_RUNTIME_A1_20261113/iso_ram_a6_release_20261116a1/cloud_delivery/rc4/source_and_docs/lab/release-iso-20261116/effective-overlay/usr/local/share/daphile-release/plugins/DaphileRME/backend/rme/ui/', import.meta.url));
const files = { '/': ['index.html', 'text/html'], '/eq-graph.js': ['eq-graph.js', 'text/javascript'],
  '/studio.js': ['studio.js', 'text/javascript'], '/style.css': ['style.css', 'text/css'] };
const makeBands = (gain = 0) => Array.from({ length: 5 }, (_, i) => ({
  band: i + 1, frequency: 1000, gain, q: 1, ...([0, 4].includes(i) ? { type: 0 } : {}),
}));
const outputs = ['line', 'phones', 'iem'];
const byOutput = (make) => Object.fromEntries(outputs.map((name) => [name, make()]));
const labels = { options: ['USB'] };
const names = [{ identifier: 1, name: 'Studio' }, { identifier: 33, name: 'Ascolto' }];
const state = {
  identity: 'a'.repeat(64), revision: 'b'.repeat(64), read_time: Date.now() / 1000,
  hardware_names: names, pending: null, context: { chip: 'unknown' }, device: { clock_source: 0, sample_rate: 0 },
  outputs: byOutput(() => ({ eq_preset: 0, dual_eq: false, source: 0, volume: -38 })),
  current_eq: byOutput(() => ({ left: makeBands(), right: makeBands(), eq_enabled: 1, eq_enabled_right: 1 })),
  capabilities: {
    outputs: byOutput(() => ({ dual_eq: { writable: true }, source: labels })),
    device: { clock_source: labels, sample_rate: { options: ['44.1 kHz'] } },
  },
};
const limits = Object.fromEntries(['eq_save', 'eq_rename', 'setup_load', 'setup_save', 'setup_rename', 'factory', 'preset_clear']
  .map((key) => [key, 'Disponibilità da verificare']));
const trace = [];
let verifiedActivations = 0;
let initialReadRejected = false;
const report = Promise.withResolvers();
const source = `(${checkPage.toString()})();`;

function checkPage() {
  const byId = (id) => document.getElementById(id);
  const ensure = (condition, description) => { if (!condition) throw Error(description); };
  const waitFor = async (predicate, description, timeout = 3000) => {
    const deadline = performance.now() + timeout;
    while (!predicate() && performance.now() < deadline) await new Promise((resolve) => setTimeout(resolve, 20));
    ensure(predicate(), description);
  };
  const click = (id) => {
    const element = byId(id);
    ensure(element && !element.disabled, `Pulsante indisponibile: ${id}`);
    element.click();
  };
  const change = (id, value) => {
    const element = byId(id);
    ensure(element && !element.disabled, `Selettore indisponibile: ${id}`);
    element.value = value;
    element.dispatchEvent(new Event('change', { bubbles: true }));
  };
  const run = async () => {
    await waitFor(() => /Prima lettura/.test(byId('connection').textContent), 'Attesa visibile senza snapshot iniziale');
    ensure(byId('eq-enabled').disabled && !byId('read').disabled, 'Rileggi disponibile durante l’attesa iniziale');
    document.querySelector('[data-view="setups"]').click();
    ensure(!byId('setup-names').closest('[data-page]').hidden, 'Navigazione disponibile prima della lettura');
    document.querySelector('[data-view="eq"]').click();
    click('read');
    await waitFor(() => /occupato/.test(byId('message').textContent) && !byId('read').disabled,
        'La lettura rifiutata lascia disponibile il ripristino');
    await waitFor(() => !byId('eq-enabled').disabled && /DAC letto/i.test(byId('connection').textContent), 'Avvio e lettura iniziale del pannello');
    ensure(!['save-slot', 'delete-slot', 'export-backup', 'import-backup', 'select-manual'].some(byId), 'Controlli preset rimossi o duplicati');
    ensure(byId('hardware-slot').closest('[data-page]').dataset.page==='eq', 'Memorie presenti nell’equalizzatore');
    ensure(Array.from(byId('hardware-slot').options, (option) => option.value).join(',') === ['manual', ...Array.from({ length: 20 }, (_, i) => String(i + 1))].join(','), 'Manual e le venti memorie numerate, una sola volta');
    ensure(byId('setup-names').children.length === 9 && byId('setup-names').textContent.includes('Ascolto'), 'Nove Setup e nome letto dal DAC');
    document.querySelector('[data-view="setups"]').click();
    ensure(!byId('setup-names').closest('[data-page]').hidden && byId('hardware-slot').closest('[data-page]').hidden, 'Setup in pagina separata');
    document.querySelector('[data-view="eq"]').click();

    change('output', 'phones');
    change('hardware-slot', '20');
    await waitFor(() => /vuota/.test(byId('message').textContent) && byId('hardware-slot').value==='manual' &&
        !byId('hardware-slot').disabled, 'Memoria vuota, resta attivo Manual');

    change('hardware-slot', '1');
    await waitFor(() => /continuare a navigare/.test(byId('sync-state').textContent), 'Avviso durante una risposta lenta', 5500);
    document.querySelector('[data-view="setups"]').click();
    ensure(!byId('setup-names').closest('[data-page]').hidden, 'Navigazione disponibile durante il richiamo');
    document.querySelector('[data-view="eq"]').click();
    await waitFor(() => /verificato/.test(byId('message').textContent) && !byId('hardware-slot').disabled,
        'La selezione richiama automaticamente il preset');
    ensure(/Phones.*Studio/.test(byId('active-hardware').textContent), 'Riepilogo del DAC aggiornato');
    ensure(document.querySelector('#bands [data-field="gain"]').value==='-1' &&
        byId('graph').querySelector('path'), 'La curva confermata arriva al grafico e alla tabella');

    change('hardware-slot', 'manual');
    await waitFor(() => /verificato/.test(byId('message').textContent) && !byId('hardware-slot').disabled,
        'Manual automatico e verificato');
    ensure(/Phones.*Manual/.test(byId('active-hardware').textContent), 'Riepilogo aggiornato a Manual');

    change('hardware-slot', '1');
    await waitFor(() => byId('message').classList.contains('error') && !byId('hardware-slot').disabled,
        'Readback negativo esposto come errore');
    ensure(byId('hardware-slot').value==='manual', 'Con esito incerto resta la selezione verificata');

    change('hardware-slot','2');
    await waitFor(() => /Risposta interrotta/.test(byId('message').textContent), 'Risposta HTTP persa gestita');
    ensure(byId('hardware-slot').disabled && !byId('read').disabled, 'Prima di nuove scritture è disponibile la rilettura');
    click('read');
    await waitFor(() => /Lettura verificata/.test(byId('message').textContent) && !byId('hardware-slot').disabled,
        'Recupero dopo risposta persa senza ricaricare la pagina');

    change('store-slot','20');
    ensure(byId('hardware-slot').value==='manual', 'Scegliere la destinazione di salvataggio lascia attivo Manual');
    byId('preset-name').value='Ascolto sera';
    byId('preset-name').dispatchEvent(new Event('input'));
    click('store-hardware');
    await waitFor(() => /Ascolto sera.*verificato/.test(byId('message').textContent) && !byId('store-hardware').disabled,
        'Salvataggio con nome da Equalizzatore');
    ensure(Array.from(byId('hardware-slot').options).find((option)=>option.value==='20').textContent.includes('Ascolto sera'),
        'Il nome riletto compare in entrambi i selettori');
    ensure(byId('eq-enabled').getAttribute('aria-checked')==='true' && byId('eq-enabled').textContent==='Disattiva EQ', 'Interruttore attivo');
    click('eq-enabled');
    await waitFor(() => byId('eq-enabled').getAttribute('aria-checked')==='false' && byId('eq-enabled').textContent==='Attiva EQ', 'Interruttore spento dopo rilettura');
    click('eq-enabled');
    await waitFor(() => !byId('recover-main').hidden && !byId('recover-main').disabled, 'Recupero accessibile dopo rollback incompleto');
    ensure(byId('retry-sync').hidden && byId('eq-enabled').disabled, 'Blocca nuovi SET e la ripetizione prima del recupero');
    click('recover-main');
    await waitFor(() => byId('recover-main').hidden && !byId('eq-enabled').disabled && /recupero riletto/.test(byId('message').textContent), 'Recupero confermato e controlli sbloccati');
  };
  run().then(() => ({ ok: true }), (error) => ({ ok: false, error: error.message, ui: byId('message')?.textContent }))
    .then((value) => fetch('/__test/result', { method: 'POST', body: JSON.stringify(value) }));
}

async function request(req, res) {
  const send = (body, code = 200) => res.writeHead(code, { 'Content-Type': 'application/json' }).end(JSON.stringify(body));
  const chunks = [];
  for await (const chunk of req) chunks.push(chunk);
  const body = chunks.length ? JSON.parse(Buffer.concat(chunks).toString('utf8')) : undefined;
  if (req.url === '/__test/result') { send({ ok: true }); report.resolve(body); return; }
  if (req.url === '/__test/page.js') { res.writeHead(200, { 'Content-Type': 'text/javascript' }).end(source); return; }
  if (files[req.url]) {
    const [name, type] = files[req.url];
    const raw = await readFile(join(ui, name), 'utf8').catch((error) => {
      if (error.code !== 'ENOENT' || !['style.css', 'eq-graph.js'].includes(name)) throw error;
      return readFile(join(baseUi, name), 'utf8');
    });
    res.writeHead(200, { 'Content-Type': `${type}; charset=utf-8` });
    res.end(name === 'index.html' ? raw.replace('</body>', '<script src="/__test/page.js" defer></script></body>') : raw);
    return;
  }
  if (!req.url.startsWith('/api/')) { res.writeHead(404).end(); return; }
  trace.push({ path: req.url, body });
  switch (req.url) {
    case '/api/session': send({ authenticated: true }); break;
    case '/api/rme/snapshot':
      if (!initialReadRejected) {
        initialReadRejected=true;
        send({error:'Busy'},409);
      } else send(state);
      break;
    case '/api/rme/state': send({ state: initialReadRejected ? state : null, refreshing: !initialReadRejected }); break;
    case '/api/rme/memory': send({ names, limits }); break;
    case '/api/rme/memory/read': {
      const { slot } = body;
      assert.ok(Number.isInteger(slot) && slot >= 1 && slot <= 20);
      send({ slot, name: slot === 1 ? 'Studio' : `Preset ${slot}`, empty: slot !== 1, dual_eq: false,
        ...(slot === 1 ? { channels: { left: makeBands(-1), right: makeBands(-1) }, tones: { bass_gain: 0, treble_gain: 0 } } : {}),
        read_only: true, fingerprint: 'f'.repeat(64), settings_write_commands_sent: 0 });
      break;
    }
    case '/api/rme/memory/store':
      assert.deepEqual(body,{confirm:true,patch:{output:'phones',slot:20,expected:state.revision,fingerprint:'f'.repeat(64),replace:false,name:'Ascolto sera'}});
      send({status:'stored-verified',readback_verified:true,memory:{slot:20,name:'Ascolto sera',hardware_name:'Ascolto sera',empty:false,dual_eq:false,
          channels:{left:makeBands(),right:makeBands()},tones:{bass_gain:0,treble_gain:0}}});
      break;
    case '/api/rme/eq/apply': {
      assert.deepEqual(body.patch,{output:'phones',expected:state.revision,side:'stereo',bands:[],enabled:!Boolean(state.current_eq.phones.eq_enabled)});
      if(body.patch.enabled){state.pending={id:'test',status:'rollback-incomplete'};send({status:'rollback-incomplete'});break;}
      Object.assign(state.current_eq.phones,{eq_enabled:0,eq_enabled_right:0});
      state.revision='e'.repeat(64);
      send({status:'applied-verified',readback_verified:true,state});
      break;
    }
    case '/api/rme/control/recover':
      assert.deepEqual(body,{confirm:true});
      state.pending=null;
      send({status:'recovered-verified'});
      break;
    case '/api/rme/preset/apply': {
      const { output, slot, expected } = body.patch;
      if (expected !== state.revision) { send({ error: 'Revisione non corrente' }, 412); break; }
      if (slot===20) { send({error:'La memoria 20 è vuota.'},400); break; }
      if (slot===2) { res.writeHead(502,{'Content-Type':'text/plain'}).end('Proxy timeout'); break; }
      if (verifiedActivations === 2) { send({ status: 'applied-verified', readback_verified: false, state }); break; }
      const hardware = slot === 1;
      if (verifiedActivations===0) await new Promise(resolve=>setTimeout(resolve,4550));
      state.revision = (verifiedActivations === 0 ? 'c' : 'd').repeat(64);
      state.outputs[output].eq_preset = hardware ? 2 : 0;
      Object.assign(state.current_eq[output], { left: makeBands(hardware ? -1 : 0), right: makeBands(hardware ? -1 : 0) });
      verifiedActivations++;
      send({ status: 'applied-verified', readback_verified: true, state });
      break;
    }
    default: send({ error: `Richiesta GUI inattesa: ${req.url}` }, 404);
  }
}

async function browserPath() {
  if (process.env.CHROME_PATH) return process.env.CHROME_PATH;
  for (const filename of ['C:/Program Files/Google/Chrome/Application/chrome.exe', 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe']) {
    try { await access(filename); return filename; } catch { /* Try the other browser. */ }
  }
  return 'chromium';
}

await access(join(ui, 'index.html'));
const browser = await browserPath();
const profile = await mkdtemp(join(tmpdir(), 'rme-presets-'));
const server = createServer((req, res) => {
  request(req, res).catch((error) => { report.reject(error); res.writeHead(500).end(); });
});
const timer = setTimeout(() => report.reject(Error(`Timeout del browser. Richieste: ${JSON.stringify(trace)}`)), 20000);
let chrome;
let browserErrors = '';
try {
  server.listen(0, '127.0.0.1');
  await once(server, 'listening');
  const flags = ['--headless=new', '--no-first-run', '--disable-gpu', '--disable-background-networking', `--user-data-dir=${profile}`];
  if (process.env.RME_TEST_CHROME_NO_SANDBOX === '1') flags.push('--no-sandbox');
  chrome = spawn(browser, [...flags, `http://127.0.0.1:${server.address().port}/`], { windowsHide: true, stdio: ['ignore', 'ignore', 'pipe'] });
  chrome.stderr.on('data', (data) => { browserErrors = (browserErrors + data).slice(-3000); });
  chrome.on('error', report.reject);
  chrome.on('close', (code) => report.reject(Error(`Il browser è terminato: ${code}\n${browserErrors}`)));
  const result = await report.promise;
  assert.equal(result.ok, true, result.error && `${result.error}\nPannello: ${result.ui}\nRichieste: ${JSON.stringify(trace)}`);
  assert.deepEqual(trace.filter(({ path }) => path === '/api/rme/preset/apply').map(({ body }) => body), [
    { confirm: true, patch: { output: 'phones', expected: 'b'.repeat(64), slot: 20 } },
    { confirm: true, patch: { output: 'phones', expected: 'b'.repeat(64), slot: 1 } },
    { confirm: true, patch: { output: 'phones', expected: 'c'.repeat(64), slot: 'manual' } },
    { confirm: true, patch: { output: 'phones', expected: 'd'.repeat(64), slot: 1 } },
    { confirm: true, patch: { output: 'phones', expected: 'd'.repeat(64), slot: 2 } },
  ]);
  const readPaths = new Set(['/api/session', '/api/rme/snapshot', '/api/rme/state', '/api/rme/memory', '/api/rme/memory/read']);
  assert.ok(trace.every(({ path }) => readPaths.has(path) || ['/api/rme/preset/apply','/api/rme/memory/store','/api/rme/eq/apply','/api/rme/control/recover'].includes(path)));
  assert.equal(trace.find(({ path }) => path === '/api/rme/memory/read').body.slot, 20);
  assert.equal(state.outputs.phones.eq_preset, 0);
  assert.equal(state.outputs.line.eq_preset, 0);
  console.log('PASS RME in Chromium: avvio lento, 409 iniziale, navigazione durante il richiamo, riconciliazione di risposta persa, preset e interruttore EQ.');
} finally {
  clearTimeout(timer);
  server.close();
  if (chrome?.pid && chrome.exitCode === null) { const closed = once(chrome, 'close'); chrome.kill(); await closed; }
  const name = relative(tmpdir(), profile);
  if (/^rme-presets-[^/\\]+$/.test(name) && !isAbsolute(name)) {
    await rm(profile, { recursive: true, force: true, maxRetries: 5, retryDelay: 100 });
  }
}
