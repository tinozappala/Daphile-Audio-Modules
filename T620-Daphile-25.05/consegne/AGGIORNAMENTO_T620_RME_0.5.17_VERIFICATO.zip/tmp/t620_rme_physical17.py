from copy import deepcopy
from http.client import HTTPConnection
import json

def api(path,payload=None):
    global cookie
    c=HTTPConnection('127.0.0.1',80,timeout=42)
    headers={'Content-Type':'application/json'}
    if cookie:headers['Cookie']=cookie
    try:
        c.request('POST' if payload is not None else 'GET','/cgi-bin/RMEPlugin/api/'+path,json.dumps(payload) if payload is not None else None,headers)
        r=c.getresponse()
        if r.getheader('Set-Cookie'):cookie=r.getheader('Set-Cookie').split(';')[0]
        v=json.loads(r.read())
        if r.status!=200:raise RuntimeError((path,r.status,v.get('error')))
        return v
    finally:c.close()

def setval(route,**patch):
    global s
    v=api('rme/'+route,{'confirm':True,'patch':dict(output=o,expected=s['revision'],**patch)})
    print(route,v['status'],v.get('reason'),flush=True)
    assert v.get('readback_verified') and v['status'] in ('applied-verified','no-change')
    s=v['state']
def snapshot():return api('rme/snapshot',{})
def equivalent(a,b):
    return all(a[k]==b[k] for k in ('outputs','current_eq','device'))
def undo():
    global s
    v=api('rme/control/restore',dict(confirm=True,output=o,expected=s['revision']))
    print('undo',v['status'],v.get('reason'),flush=True)
    assert v.get('readback_verified')
    s=v['state']
cookie=None
api('session');s=snapshot();base=deepcopy(s);o='phones'
print('baseline',[(k,v['eq_preset']) for k,v in s['outputs'].items()],flush=True)
assert not s['pending'] and s['outputs'][o]['eq_preset']==0
bank=api('rme/memory/read',{'slot':1})
assert not bank['empty']
setval('preset/apply',slot=1)
preset=deepcopy(s)
try:
    assert not s['current_eq'][o]['dual_eq'] or s['current_eq'][o]['left']==s['current_eq'][o]['right']
    rows=deepcopy(s['current_eq'][o]['left'])
    for row in rows:row['q']=round(row['q']+(.1 if row['q']<5 else -.1),1)
    setval('eq/apply',side='stereo',bands=rows)
    snap=snapshot()
    print('physical EQ selector',snap['outputs'][o]['eq_preset'],flush=True)
    assert all(snap['current_eq'][o][side]==rows for side in ('left','right'))
    assert api('rme/memory/read',{'slot':1})['fingerprint']==bank['fingerprint']
    undo();assert equivalent(s,preset)
    for key in ('tone_enabled','dual_eq'):
        setval('control/apply',values={key:not preset['outputs'][o][key]})
        assert snapshot()['outputs'][o][key]!=preset['outputs'][o][key]
        undo();assert equivalent(s,preset)
    enabled=bool(s['current_eq'][o]['eq_enabled'])
    setval('eq/apply',side='stereo',bands=[],enabled=not enabled)
    assert bool(snapshot()['current_eq'][o]['eq_enabled'])!=enabled
    undo();assert equivalent(s,preset)
finally:
    latest=snapshot()
    if equivalent(latest,preset) and not latest['pending']:
        s=latest
        setval('preset/apply',slot='manual')
    print('original baseline restored',equivalent(snapshot(),base),flush=True)
assert equivalent(snapshot(),base)
