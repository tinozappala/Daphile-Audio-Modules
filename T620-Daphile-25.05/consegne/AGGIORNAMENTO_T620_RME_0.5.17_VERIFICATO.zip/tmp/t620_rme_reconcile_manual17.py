from pathlib import Path
import json, os, subprocess, sys, tempfile

assert Path('/sys/class/dmi/id/product_name').read_text().strip()=='HP t620 Quad Core TC'
assert Path('/version').read_text().strip()=='fw2505251550'
host=Path('/mnt/hdd/system/daphile-audio-host')
module=host/'modules/DaphileRME'
release=module/'releases'/json.loads((module/'current.json').read_text())['release']
state=Path(json.loads((host/'config.json').read_text())['rme_state'])
sys.path.insert(0,str(release/'rme/lib'))
import rme_control as ctl, rme_peq as peq
camilla=host/'modules/DaphileCamillaDSP/process.json'
camilla_before=camilla.read_bytes()

with ctl.operation(state,True) as private:
    path=private/'transaction.json'
    raw=path.read_bytes(); j=json.loads(raw)
    assert j['status']=='rollback-incomplete' and j['output']=='line' and j['selection'] is False
    assert j['writes_attempted']==['4:2'] 
    assert j['desired']=={'4:2':1,'5:2':1}
    originals=ctl.values(j['before'])
    assert all(originals[k]==0 for k in ('4:2','5:2','4:20')) and originals['4:27']==1 and originals['4:28']==0 and j.get('request_finished') and not peq.parent_alive(j)
    expected={**j['desired'],'4:20':1}
    for _ in range(2):
        after=peq.verified_read()
        assert after['usb_serial']==j['before']['usb_serial']
        assert originals['12:16']==3 and ctl.values(after)['12:16']==0
        ctl.check(j['before'],after,{**expected,'12:16':0},allow_dependencies=False)
    assert path.read_bytes()==raw
    backup=Path(tempfile.mkdtemp(prefix='rme-eq-on-',dir=host/'recovery'))
    (backup/'transaction.before.json').write_bytes(raw)
    os.chmod(backup/'transaction.before.json',0o600)
    prior=private/'last-line.json'
    if prior.is_file():
        (backup/'last-line.before.json').write_bytes(prior.read_bytes())
        os.chmod(backup/'last-line.before.json',0o600)
    j.update(status='committed',readback_verified=True,desired=expected,derived={'4:20':1},reconciled=True)
    ctl.atomic(private/('after-'+j['id']+'.json'),after)
    j['observation']='Sample rate subsequently changed from 96 to 44.1 kHz. Archived without creating a new undo point.'
    ctl.atomic(path,j)
    print('Verified prior EQ On and automatic B/T On on all 220 registers without any DAC writes',flush=True)

result=subprocess.run([sys.executable,'-B',str(host/'code/hostctl.py'),'sync','--root',str(host),'--module','DaphileRME'],capture_output=True,text=True,timeout=50,check=True)
readback=json.loads(result.stdout)
assert readback['running'] and not readback['recovery_required']
assert camilla.read_bytes()==camilla_before
print('RME controller available, Camilla process intact',flush=True)

