from copy import deepcopy
from http.client import HTTPConnection
import json

def api(path,payload=None):
    global cookie
    c=HTTPConnection('127.0.0.1',80,timeout=42)
    headers={'Content-Type':'application/json'}
    if cookie:headers['Cookie']=cookie
    try:
        c.request('POST' if payload is not None else 'GET','/cgi-bin/RMEPlugin/api/'+path,json.dumps(payload) if payload is not None else None,headers)
        r=c.getresponse()
        if r.getheader('Set-Cookie'):cookie=r.getheader('Set-Cookie').split(';')[0]
        v=json.loads(r.read())
        if r.status!=200:raise RuntimeError((path,r.status,v.get('error')))
        return v
    finally:c.close()

def setval(route,**patch):
    global s
    v=api('rme/'+route,{'confirm':True,'patch':dict(output=o,expected=s['revision'],**patch)})
    print(route,v['status'],v.get('reason'),flush=True)
    assert v.get('readback_verified') and v['status'] in ('applied-verified','no-change')
    s=v['state']
def snapshot():return api('rme/snapshot',{})
def equivalent(a,b):
    return all(a[k]==b[k] for k in ('outputs','current_eq','device'))
def undo():
    global s
    v=api('rme/control/restore',dict(confirm=True,output=o,expected=s['revision']))
    print('undo',v['status'],v.get('reason'),flush=True)
    assert v.get('readback_verified')
    s=v['state']
cookie=None
api('session');s=snapshot();base=deepcopy(s);o='line'
assert not s['pending'] and s['outputs'][o]['eq_preset']==0 and s['outputs'][o]['load_tones_with_preset']
assert s['outputs'][o]['tone_enabled'] and s['current_eq'][o]['eq_enabled']
for target in (False, True):
    setval('eq/apply',side='stereo',bands=[],enabled=target)
    v=snapshot();assert not v['pending'] and all(bool(v['current_eq'][o][k])==target for k in ('eq_enabled','eq_enabled_right'))
    assert v['outputs'][o]['tone_enabled']==target
    print('Line Manual EQ and tones',target,flush=True)
assert equivalent(v,base)
print('Line original baseline restored',flush=True)
